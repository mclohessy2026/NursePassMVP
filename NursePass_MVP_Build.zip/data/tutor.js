// Clinical knowledge base for the NursePass AI Tutor. Each entry is matched on
// keywords and returns a structured, exam-focused explanation.

export const SUGGESTIONS = [
  'Explain digoxin toxicity',
  'How do I prioritize 4 clients?',
  'Hypokalemia vs hyperkalemia',
  'What is an NGN bow-tie item?',
  'Interpret ABGs fast',
  'Preeclampsia red flags',
  'Which tasks can I delegate?',
  'Build me a 2-week study plan',
];

const TOPICS = [
  {
    keys: ['digoxin', 'dig toxicity', 'lanoxin'],
    title: 'Digoxin — the exam essentials',
    body:
      'Digoxin is a positive inotrope and negative chronotrope: it strengthens contraction and slows conduction through the AV node.\n\n• Therapeutic level: 0.5–2.0 ng/mL. Toxic above 2.0.\n• Hold the dose if the adult apical pulse is under 60 (under 70 in children, under 90 in infants) and notify the provider.\n• Early toxicity: anorexia, nausea, vomiting, yellow-green halos, new confusion in older adults, bradycardia or dysrhythmias.\n• Hypokalemia potentiates toxicity, so watch clients on loop diuretics closely — that pairing is a favorite test scenario.\n• Antidote: digoxin immune Fab (DigiFab).\n\nExam tip: when a question gives you both digoxin and furosemide, the answer almost always involves checking the potassium level.',
  },
  {
    keys: ['potassium', 'hypokalemia', 'hyperkalemia', 'k+'],
    title: 'Potassium imbalances side by side',
    body:
      'Normal potassium is 3.5–5.0 mEq/L, and both extremes are lethal through the heart.\n\nHypokalemia (under 3.5)\n• Causes: loop diuretics, vomiting, NG suction, insulin, alkalosis.\n• Signs: muscle weakness, leg cramps, decreased bowel sounds/ileus, shallow respirations.\n• ECG: flat or inverted T waves, ST depression, U waves.\n• Care: potassium-rich foods, oral or IV replacement — never IV push, always on a pump, max about 10 mEq/hr on a general unit, and confirm urine output first.\n\nHyperkalemia (over 5.0)\n• Causes: renal failure, ACE inhibitors, potassium-sparing diuretics, crush injury, acidosis.\n• Signs: muscle twitching then weakness, diarrhea, dysrhythmias.\n• ECG: tall peaked T waves, widened QRS.\n• Care: calcium gluconate to stabilize the myocardium, insulin with dextrose, sodium bicarbonate, albuterol, then sodium polystyrene or dialysis to remove it.',
  },
  {
    keys: ['prioriti', 'which client first', 'abc', 'maslow'],
    title: 'Prioritization framework that actually works',
    body:
      'Work down this decision ladder in order.\n\n1. ABC — airway, then breathing, then circulation. Anything threatening the airway wins (stridor, throat tightness after thyroidectomy, facial burns).\n2. Acute over chronic, unstable over stable, unexpected over expected. New-onset chest pain beats a scheduled dressing change.\n3. Trends matter: a falling blood pressure or rising lactate outranks one abnormal-but-stable value.\n4. Maslow when everyone is physiologically stable — safety before psychosocial, psychosocial before teaching.\n5. Least invasive / assessment first if the question asks "what should the nurse do first."\n\nExam tip: expected post-op findings (low-grade fever day 1, serosanguineous drainage) are distractors, not emergencies.',
  },
  {
    keys: ['delegat', 'uap', 'lpn', 'assignment'],
    title: 'Delegation rules (the five rights)',
    body:
      'Delegate the right task, in the right circumstances, to the right person, with the right direction and the right supervision.\n\n• UAP: vital signs on stable clients, hygiene, feeding, ambulation, transfers, intake and output, positioning, specimen collection.\n• LPN/LVN: stable clients — routine medications (many states exclude IV push), sterile dressing changes, tracheostomy care, reinforcing established teaching, tube feedings.\n• RN only: assessment, initial teaching, evaluation, care planning, blood administration, IV titration, unstable clients, anything requiring nursing judgment.\n\nMnemonic: you cannot delegate the nursing process. If the answer choice involves assess, teach, evaluate, or plan — it stays with the RN.',
  },
  {
    keys: ['abg', 'acid base', 'respiratory acidosis', 'metabolic alkalosis'],
    title: 'ABG interpretation in 20 seconds (ROME)',
    body:
      'Normals: pH 7.35–7.45, PaCO2 35–45 mm Hg, HCO3 22–26 mEq/L.\n\nStep 1: Is the pH low (acidosis) or high (alkalosis)?\nStep 2: Use ROME — Respiratory Opposite, Metabolic Equal.\n• pH down with CO2 up = respiratory acidosis (hypoventilation: COPD, opioid overdose, atelectasis).\n• pH up with CO2 down = respiratory alkalosis (hyperventilation, anxiety, pulmonary embolism early).\n• pH down with HCO3 down = metabolic acidosis (DKA, renal failure, diarrhea, shock).\n• pH up with HCO3 up = metabolic alkalosis (vomiting, NG suction, excess antacids).\nStep 3: Compensation — if the other value has also shifted, the body is compensating; if the pH is back in range, it is fully compensated.',
  },
  {
    keys: ['preeclampsia', 'eclampsia', 'magnesium sulfate', 'hellp'],
    title: 'Preeclampsia and magnesium sulfate',
    body:
      'Preeclampsia is new hypertension (140/90 or higher) after 20 weeks with proteinuria or end-organ signs.\n\nSevere features to report immediately: BP 160/110 or higher, severe headache unrelieved by acetaminophen, visual changes, epigastric or right upper quadrant pain, platelets under 100,000, rising creatinine, pulmonary edema.\n\nMagnesium sulfate prevents seizures, it is not an antihypertensive.\n• Monitor: deep tendon reflexes, respiratory rate over 12, urine output at least 30 mL/hr, level of consciousness, magnesium level (therapeutic 4–7 mEq/L).\n• Toxicity: loss of reflexes first, then respiratory depression, then cardiac arrest.\n• Antidote: calcium gluconate at the bedside.\n\nSeizure precautions: quiet, dim, low-stimulation room with suction and oxygen ready.',
  },
  {
    keys: ['ngn', 'bow-tie', 'bowtie', 'next gen', 'case study', 'matrix'],
    title: 'Next Generation NCLEX item types',
    body:
      'NGN tests clinical judgment using the NCJMM: recognize cues, analyze cues, prioritize hypotheses, generate solutions, take action, evaluate outcomes.\n\nItem types you will see:\n• Matrix / grid — mark each finding as expected vs unexpected, or therapeutic vs adverse.\n• Bow-tie — drag one condition into the center, two actions on the left, two parameters to monitor on the right.\n• Highlight — tap the findings in a chart note that require follow-up.\n• Drop-down cloze — complete sentences from menus.\n• Extended multiple response — select all that apply with partial credit.\n\nStrategy: read the last sentence of the stem first so you know what is being asked, then mine the chart tabs for data that answers exactly that. NGN uses partial scoring, so answer every row.',
  },
  {
    keys: ['insulin', 'diabet', 'dka', 'glucose'],
    title: 'Insulin timing and diabetic emergencies',
    body:
      'Onset / peak you must memorize:\n• Rapid (lispro, aspart): onset 15 min, peak 1 hr — give with food in hand.\n• Regular: onset 30–60 min, peak 2–3 hr — the only insulin given IV.\n• NPH: onset 1–2 hr, peak 4–12 hr — cloudy, never IV.\n• Glargine/detemir: no pronounced peak, do not mix.\nMixing order: clear before cloudy (regular then NPH).\n\nDKA (type 1): glucose over 250, pH under 7.3, ketones, Kussmaul respirations, fruity breath. Treat with isotonic fluids first, then a regular insulin infusion, then potassium as it shifts intracellularly.\nHHS (type 2): glucose often over 600, no significant ketosis, profound dehydration and neuro changes. Fluids are the cornerstone.\nHypoglycemia (under 70): 15 g fast carbohydrate, recheck in 15 minutes; if unconscious give D50 IV or glucagon IM.',
  },
  {
    keys: ['heart failure', 'chf', 'pulmonary edema', 'left sided'],
    title: 'Heart failure: left versus right',
    body:
      'Left-sided failure backs up into the lungs — think "lung" words: dyspnea, orthopnea, paroxysmal nocturnal dyspnea, crackles, pink frothy sputum, S3 gallop, fatigue.\nRight-sided failure backs up into the body — think "body" words: jugular vein distention, peripheral and sacral edema, hepatomegaly, ascites, weight gain.\n\nPriority nursing actions: high Fowler position, oxygen, daily weights (report 2–3 lb in a day or 5 lb in a week), sodium and fluid restriction, monitor potassium on diuretics, and teach clients to report worsening dyspnea early.\n\nBNP over 100 pg/mL supports the diagnosis and rises with severity.',
  },
  {
    keys: ['icp', 'head injury', 'intracranial', 'cushing triad'],
    title: 'Increased intracranial pressure',
    body:
      'Normal ICP is 5–15 mm Hg. Early signs are subtle: restlessness, confusion, decreasing level of consciousness, headache, pupil sluggish on one side.\nLate/ominous: Cushing triad (widening pulse pressure, bradycardia, irregular respirations), projectile vomiting, posturing, fixed dilated pupils.\n\nDo: head of bed 30 degrees with the neck neutral, head midline, quiet environment, prevent Valsalva (stool softeners, no suctioning longer than 10 seconds), treat fever, maintain normal oxygen and CO2, mannitol or hypertonic saline as ordered.\nAvoid: hip flexion, clustering care activities, coughing, hypotonic IV fluids, and suctioning without preoxygenation.',
  },
  {
    keys: ['therapeutic communication', 'what should the nurse say', 'response'],
    title: 'Therapeutic communication shortcuts',
    body:
      'Choose the option that reflects feelings, invites exploration, or stays with the client.\n\nTherapeutic: open-ended questions, silence, restating, reflecting, offering self ("I will sit with you"), clarifying, validating.\nNon-therapeutic and always wrong on the exam: false reassurance ("everything will be fine"), giving advice, asking "why," changing the subject, minimizing, defending staff or the provider, and focusing on the family instead of the client.\n\nQuick filter: if the answer talks about anyone other than the client, or promises an outcome the nurse cannot guarantee, eliminate it.',
  },
  {
    keys: ['infection', 'precaution', 'isolation', 'tb', 'c diff', 'mrsa'],
    title: 'Isolation precautions cheat sheet',
    body:
      'Airborne (negative-pressure room, N95): tuberculosis, measles, varicella, disseminated zoster, COVID-19 during aerosolizing procedures. Mnemonic: My Chicken Hez TB.\nDroplet (private room, surgical mask within 3–6 feet): influenza, pertussis, meningitis (Neisseria), mumps, rubella, group A strep.\nContact (gown and gloves, dedicated equipment): C. difficile, MRSA, VRE, RSV, scabies, impetigo, draining wounds.\n\nSpecial notes: C. difficile requires soap and water hand hygiene and bleach cleaning because alcohol does not kill spores. Neutropenic clients get protective precautions — no fresh flowers, no raw foods, and no sick visitors.',
  },
  {
    keys: ['study plan', 'schedule', 'how should i study', 'plan'],
    title: 'A 2-week NursePass study plan',
    body:
      'Days 1–3 — Diagnose: one 40-question adaptive session per day across all categories. Review every rationale, right or wrong, and let the readiness heat map surface your two weakest subcategories.\nDays 4–8 — Attack weak areas: 40 targeted questions daily in your two red subcategories, plus one Boss Battle round for pharmacology recall. Keep a one-page "why I missed it" log.\nDays 9–11 — NGN focus: matrix and select-all items only, 30 per day. Practice reading the last line of the stem first.\nDays 12–13 — Simulate: two full 40-question timed sessions, no pausing, same time of day as your exam appointment.\nDay 14 — Taper: 20 easy questions to stay warm, review your log, sleep 8 hours.\n\nUse your readiness score as a trend, not a pass prediction. Prioritize consistent improvement, careful rationale review, and the weakest blueprint areas before test day.',
  },
  {
    keys: ['oxygen', 'copd', 'respiratory', 'asthma'],
    title: 'Oxygenation and COPD care',
    body:
      'Target SpO2 is 92–98% for most adults but 88–92% for chronic CO2 retainers with COPD — high-flow oxygen can blunt their hypoxic drive.\n\nDelivery devices: nasal cannula 1–6 L (24–44%), simple mask 5–10 L, Venturi mask for precise concentrations (best for COPD), non-rebreather 10–15 L for the acutely unstable client.\n\nCOPD teaching: pursed-lip breathing, tripod positioning, small frequent high-calorie meals, pneumococcal and annual influenza vaccines, and the difference between rescue (albuterol) and maintenance (fluticasone, tiotropium) inhalers. When both are ordered, the bronchodilator goes first, then the steroid, then rinse the mouth.',
  },
];

const FALLBACK_INTRO = [
  'Great question — let me break this down the way the NCLEX will test it.',
  'Here is how I would frame that for exam day.',
  'Good one. Let me give you the clinical reasoning plus the test-taking angle.',
];

export function answerFor(input) {
  const text = String(input || '').toLowerCase();
  const hit = TOPICS.find((t) => t.keys.some((k) => text.includes(k)));
  if (hit) {
    return `${hit.title}\n\n${hit.body}`;
  }
  const intro = FALLBACK_INTRO[Math.floor(Math.random() * FALLBACK_INTRO.length)];
  return `${intro}\n\nFor "${String(input || '').trim()}", work through it in four steps:\n\n1. Identify the client problem — what body system or concept is being tested, and is the client stable or unstable?\n2. Recall the pathophysiology in one sentence. If you cannot, that is your study gap; drill it in Practice.\n3. Apply the priority framework — ABC, then acute over chronic, then safety, then teaching. Assessment comes before intervention unless the client is in immediate danger.\n4. Eliminate distractors: answers that are absolute ("always," "never"), that delegate nursing judgment, that offer false reassurance, or that delay care are almost always wrong.\n\nWant me to go deeper? Ask me about a specific drug, lab value, or disease process — for example "explain magnesium sulfate monitoring" or "hypokalemia vs hyperkalemia" — and I will give you the full breakdown with the numbers you need to memorize.`;
}

// Chat-friendly wrapper used by the Tutor screen. Returns the same clinical
// answer as answerFor(), guarding against empty input.
export function getTutorReply(input) {
  const text = String(input || '').trim();
  if (!text) {
    return "Ask me anything about your subjects — try \"explain digoxin toxicity\" or \"how do I prioritize 4 clients?\" and I'll walk you through it.";
  }
  return answerFor(text);
}
