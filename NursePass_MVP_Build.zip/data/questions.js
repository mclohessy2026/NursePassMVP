// NursePass starter question bank. Expand this bank only with clinically reviewed items.

export const BANK_SIZE = 40;

export const CATEGORIES = [
  {
    key: 'phys',
    name: 'Physiological Integrity',
    short: 'Physiological',
    icon: 'heart-half',
    colorIndex: 5,
    weight: 0.31,
    subs: ['Basic Care & Comfort', 'Reduction of Risk Potential', 'Physiological Adaptation'],
  },
  {
    key: 'pharm',
    name: 'Pharmacological & Parenteral Therapies',
    short: 'Pharmacological',
    icon: 'medkit',
    colorIndex: 0,
    weight: 0.29,
    subs: ['Medication Administration', 'Adverse Effects', 'Dosage Calculation', 'Blood & TPN Therapy'],
  },
  {
    key: 'psych',
    name: 'Psychosocial Integrity',
    short: 'Psychosocial',
    icon: 'happy',
    colorIndex: 4,
    weight: 0.13,
    subs: ['Coping & Adaptation', 'Mental Health Concepts', 'Therapeutic Communication'],
  },
  {
    key: 'safe',
    name: 'Safe & Effective Care Environment',
    short: 'Safe & Effective',
    icon: 'shield-checkmark',
    colorIndex: 2,
    weight: 0.27,
    subs: ['Management of Care', 'Safety & Infection Control', 'Delegation & Prioritization'],
  },
];

export function categoryByKey(key) {
  return CATEGORIES.find((c) => c.key === key) || CATEGORIES[0];
}

export const ALL_QUESTIONS = [
  // ---------------- PHARMACOLOGICAL ----------------
  {
    id: 'q1',
    category: 'pharm',
    sub: 'Medication Administration',
    difficulty: 2,
    type: 'mc',
    stem:
      'A client with heart failure is scheduled to receive digoxin 0.25 mg PO. The nurse assesses an apical pulse of 52 beats/min. Which action should the nurse take first?',
    options: [
      'Administer the digoxin and recheck the pulse in 1 hour',
      'Hold the dose and notify the health care provider',
      'Give half the ordered dose',
      'Administer the dose with a full glass of water',
    ],
    correct: 1,
    rationale:
      'Digoxin is withheld when the adult apical pulse is below 60 beats/min because the drug further slows conduction through the AV node. The nurse holds the dose, documents the rate, and notifies the provider. Never split or delay a cardiac glycoside dose on your own judgment.',
  },
  {
    id: 'q2',
    category: 'pharm',
    sub: 'Adverse Effects',
    difficulty: 3,
    type: 'mc',
    stem:
      'A client receiving warfarin has an INR of 6.8 and reports bleeding gums. Which intervention does the nurse anticipate?',
    options: [
      'Administer protamine sulfate IV',
      'Increase the warfarin dose to stabilize clotting',
      'Hold warfarin and prepare to give phytonadione (vitamin K)',
      'Encourage a diet high in leafy green vegetables today',
    ],
    correct: 2,
    rationale:
      'Therapeutic INR on warfarin is 2–3. An INR of 6.8 with active bleeding is supratherapeutic: hold the drug and give vitamin K, the specific antidote. Protamine sulfate reverses heparin, not warfarin.',
  },
  {
    id: 'q3',
    category: 'pharm',
    sub: 'Adverse Effects',
    difficulty: 1,
    type: 'mc',
    stem:
      'A client newly prescribed furosemide asks which foods to add to the diet. Which response is most appropriate?',
    options: [
      'Bananas, potatoes, and cantaloupe',
      'Cheese, milk, and yogurt',
      'Red meat and liver',
      'White rice and pasta',
    ],
    correct: 0,
    rationale:
      'Furosemide is a potassium-wasting loop diuretic, so clients need potassium-rich foods such as bananas, potatoes, oranges, and cantaloupe. Monitor for hypokalemia signs: muscle weakness, cramps, and cardiac dysrhythmias.',
  },
  {
    id: 'q4',
    category: 'pharm',
    sub: 'Medication Administration',
    difficulty: 2,
    type: 'mc',
    stem:
      'A client who takes metformin is scheduled for a CT scan with iodinated contrast. What instruction is essential?',
    options: [
      'Take metformin with extra water before the scan',
      'Hold metformin at the time of the study and for 48 hours after',
      'Double the metformin dose the morning of the scan',
      'Switch to sliding-scale insulin permanently',
    ],
    correct: 1,
    rationale:
      'Metformin combined with iodinated contrast increases the risk of contrast-induced nephropathy and lactic acidosis. It is held at the time of the study and typically for 48 hours afterward, resumed once renal function is confirmed stable.',
  },
  {
    id: 'q5',
    category: 'pharm',
    sub: 'Blood & TPN Therapy',
    difficulty: 2,
    type: 'mc',
    stem:
      'A client on a continuous heparin infusion has an aPTT of 96 seconds (control 30 seconds). Which action is correct?',
    options: [
      'Continue the infusion as ordered',
      'Increase the infusion rate per protocol',
      'Stop the infusion and notify the provider; anticipate protamine sulfate',
      'Administer vitamin K subcutaneously',
    ],
    correct: 2,
    rationale:
      'Therapeutic aPTT is 1.5–2.5 times control (about 45–75 seconds). At 96 seconds the client is over-anticoagulated: stop the infusion, notify the provider, and have protamine sulfate available as the heparin antidote.',
  },
  {
    id: 'q6',
    category: 'pharm',
    sub: 'Adverse Effects',
    difficulty: 3,
    type: 'mc',
    stem:
      'A client taking lithium has a serum level of 2.1 mEq/L and reports vomiting and coarse hand tremor. What is the nurse’s priority action?',
    options: [
      'Hold the next dose and notify the provider immediately',
      'Restrict all fluids to 1000 mL/day',
      'Give the dose with food to reduce nausea',
      'Encourage a low-sodium diet',
    ],
    correct: 0,
    rationale:
      'Therapeutic lithium is 0.6–1.2 mEq/L; above 1.5 mEq/L is toxic and above 2.0 mEq/L can cause seizures and dysrhythmias. Hold the drug, notify the provider, and maintain sodium and fluid intake — restricting sodium raises lithium levels.',
  },
  {
    id: 'q7',
    category: 'pharm',
    sub: 'Medication Administration',
    difficulty: 2,
    type: 'mc',
    stem:
      'During an IV vancomycin infusion the client develops flushing of the face and neck with pruritus. Which action should the nurse take first?',
    options: [
      'Discontinue the IV catheter',
      'Slow the infusion rate and notify the provider',
      'Administer epinephrine IM',
      'Increase the infusion to finish the dose faster',
    ],
    correct: 1,
    rationale:
      'Flushing of the face and neck during vancomycin infusion is an infusion-rate reaction (vancomycin flushing syndrome) caused by histamine release, not a true allergy. Slowing the rate and pretreating with an antihistamine usually resolves it.',
  },
  {
    id: 'q8',
    category: 'pharm',
    sub: 'Adverse Effects',
    difficulty: 1,
    type: 'mc',
    stem: 'Which statement by a client on long-term prednisone requires further teaching?',
    options: [
      'I will report black, tarry stools to my provider.',
      'I will take the medication with breakfast.',
      'I will stop the drug as soon as I feel better.',
      'I will avoid people who are sick.',
    ],
    correct: 2,
    rationale:
      'Abruptly stopping a long-term corticosteroid causes adrenal insufficiency (hypotension, weakness, hypoglycemia). The drug must be tapered. Taking it with food, reporting GI bleeding, and avoiding infection are all correct.',
  },
  {
    id: 'q9',
    category: 'pharm',
    sub: 'Dosage Calculation',
    difficulty: 2,
    type: 'mc',
    stem:
      'The provider orders amoxicillin 250 mg PO. The pharmacy supplies an oral suspension of 125 mg/5 mL. How many milliliters will the nurse administer?',
    options: ['5 mL', '7.5 mL', '10 mL', '12.5 mL'],
    correct: 2,
    rationale:
      'Desired over have times quantity: (250 mg ÷ 125 mg) × 5 mL = 10 mL. Always confirm the concentration on the label, because suspensions come in multiple strengths.',
  },
  {
    id: 'q10',
    category: 'pharm',
    sub: 'Adverse Effects',
    difficulty: 1,
    type: 'mc',
    stem: 'A client started on enalapril reports a persistent dry cough. The nurse explains that this symptom is:',
    options: [
      'A sign of heart failure worsening',
      'An expected effect of ACE inhibitors that should be reported',
      'A sign of medication overdose requiring an antidote',
      'Caused by taking the drug with food',
    ],
    correct: 1,
    rationale:
      'A dry, nonproductive cough from bradykinin accumulation occurs in up to 20% of clients on ACE inhibitors. It is not dangerous but is reported, because the provider may switch the client to an ARB such as losartan.',
  },
  {
    id: 'q11',
    category: 'pharm',
    sub: 'Medication Administration',
    difficulty: 2,
    type: 'mc',
    stem:
      'A postoperative client has a respiratory rate of 8 breaths/min two hours after IV morphine. Which medication should the nurse prepare?',
    options: ['Flumazenil', 'Naloxone', 'Acetylcysteine', 'Calcium gluconate'],
    correct: 1,
    rationale:
      'Naloxone is the opioid antagonist for respiratory depression. Flumazenil reverses benzodiazepines, acetylcysteine treats acetaminophen overdose, and calcium gluconate is used for magnesium toxicity and hyperkalemia.',
  },
  {
    id: 'q12',
    category: 'pharm',
    sub: 'Medication Administration',
    difficulty: 3,
    type: 'mc',
    stem:
      'A client receives regular insulin subcutaneously at 0730. At what time should the nurse be most alert for hypoglycemia?',
    options: ['0745–0800', '0930–1030', '1500–1700', '2200–2400'],
    correct: 1,
    rationale:
      'Regular (short-acting) insulin has an onset of 30–60 minutes and peaks in 2–3 hours, so hypoglycemia risk is greatest mid-morning after a 0730 dose. Peak time is always the highest-risk window.',
  },
  {
    id: 'q13',
    category: 'pharm',
    sub: 'Adverse Effects',
    difficulty: 2,
    type: 'sata',
    stem:
      'A nurse assesses a client for digoxin toxicity. Which findings support this concern? Select all that apply.',
    options: [
      'Anorexia and nausea',
      'Yellow-green visual halos',
      'Bradycardia with irregular rhythm',
      'Hypertension with bounding pulses',
      'Confusion in an older adult',
    ],
    correct: [0, 1, 2, 4],
    rationale:
      'Early digoxin toxicity presents with GI upset (anorexia, nausea, vomiting), visual disturbances such as yellow-green halos, bradycardia or dysrhythmias, and new confusion in older adults. Hypertension with bounding pulses is not a toxicity sign. Hypokalemia potentiates toxicity.',
  },
  {
    id: 'q14',
    category: 'pharm',
    sub: 'Blood & TPN Therapy',
    difficulty: 3,
    type: 'sata',
    stem: 'Which nursing actions are required when administering IV potassium chloride? Select all that apply.',
    options: [
      'Always dilute and infuse with an electronic infusion pump',
      'Never administer by IV push',
      'Assess urine output before infusing',
      'Infuse at a maximum of 10 mEq/hr on a general unit',
      'Give as a rapid bolus for severe hypokalemia',
    ],
    correct: [0, 1, 2, 3],
    rationale:
      'IV potassium is never given by push or bolus — it causes fatal dysrhythmias. It is always diluted, pump-controlled, generally limited to 10 mEq/hr outside critical care, and requires adequate urine output (at least 30 mL/hr) before infusing.',
  },
  {
    id: 'q15',
    category: 'pharm',
    sub: 'Adverse Effects',
    difficulty: 3,
    type: 'matrix',
    stem:
      'For each finding in a client 6 hours after starting IV furosemide, indicate whether it reflects a therapeutic response or an adverse effect.',
    caseNote:
      'Nurses’ note 1400: 68-year-old admitted with acute decompensated heart failure. IV furosemide 40 mg given at 0800. Weight on admission 84 kg. Baseline crackles bilateral bases, O2 sat 89% on room air.',
    cols: ['Therapeutic', 'Adverse'],
    rows: [
      { label: 'Urine output 1,450 mL since 0800', correct: 0 },
      { label: 'Lung sounds now clear to auscultation', correct: 0 },
      { label: 'Serum potassium 2.9 mEq/L', correct: 1 },
      { label: 'Standing blood pressure 86/52 mm Hg with dizziness', correct: 1 },
      { label: 'Weight decreased from 84 kg to 82.4 kg', correct: 0 },
    ],
    rationale:
      'Diuresis, clearing crackles, and weight loss are the intended effects of a loop diuretic. Hypokalemia (below 3.5 mEq/L) and orthostatic hypotension are adverse effects requiring potassium replacement and fall precautions.',
  },
  // ---------------- PHYSIOLOGICAL ----------------
  {
    id: 'q16',
    category: 'phys',
    sub: 'Reduction of Risk Potential',
    difficulty: 3,
    type: 'mc',
    stem:
      'A nurse notes continuous bubbling in the water-seal chamber of a client’s chest drainage system. What does this finding indicate?',
    options: [
      'Normal function of the system',
      'An air leak in the system',
      'Re-expansion of the lung',
      'Obstruction of the chest tube',
    ],
    correct: 1,
    rationale:
      'Intermittent bubbling in the water seal with respiration is expected; continuous bubbling signals an air leak. Assess connections from the client to the drainage unit and tighten or tape as indicated before notifying the provider.',
  },
  {
    id: 'q17',
    category: 'phys',
    sub: 'Basic Care & Comfort',
    difficulty: 1,
    type: 'mc',
    stem: 'Which intervention best prevents atelectasis in a client on the first day after abdominal surgery?',
    options: [
      'Encourage incentive spirometry 10 times every hour while awake',
      'Maintain strict bed rest for 24 hours',
      'Limit oral fluids to reduce secretions',
      'Administer oxygen at 6 L/min by nasal cannula',
    ],
    correct: 0,
    rationale:
      'Sustained maximal inspiration with an incentive spirometer, plus splinted coughing and early ambulation, keeps alveoli open. Bed rest and fluid restriction increase the risk of atelectasis and pneumonia.',
  },
  {
    id: 'q18',
    category: 'phys',
    sub: 'Physiological Adaptation',
    difficulty: 2,
    type: 'mc',
    stem: 'Which ECG change should the nurse expect in a client with a serum potassium of 2.8 mEq/L?',
    options: [
      'Tall, peaked T waves',
      'Flattened T waves with ST depression and U waves',
      'Shortened QT interval',
      'Absent P waves with a sawtooth pattern',
    ],
    correct: 1,
    rationale:
      'Hypokalemia flattens or inverts T waves, depresses the ST segment, and produces U waves. Tall peaked T waves indicate hyperkalemia. Both extremes predispose the client to lethal dysrhythmias.',
  },
  {
    id: 'q19',
    category: 'phys',
    sub: 'Physiological Adaptation',
    difficulty: 3,
    type: 'mc',
    stem:
      'A client with Addison disease is admitted with adrenal crisis. Which set of findings does the nurse expect?',
    options: [
      'Hypertension, hypokalemia, hyperglycemia',
      'Hypotension, hyperkalemia, hyponatremia',
      'Moon face, truncal obesity, striae',
      'Bradycardia, hypercalcemia, polyuria',
    ],
    correct: 1,
    rationale:
      'Addison disease is adrenal cortical insufficiency: loss of aldosterone causes sodium and water loss with potassium retention, so the client is hypotensive, hyperkalemic, hyponatremic, and hypoglycemic. The first three options describe Cushing syndrome or other states.',
  },
  {
    id: 'q20',
    category: 'phys',
    sub: 'Physiological Adaptation',
    difficulty: 3,
    type: 'mc',
    stem:
      'A client with acute respiratory distress syndrome remains hypoxemic on high FiO2. Which position should the nurse anticipate?',
    options: ['Prone positioning', 'High Fowler with legs dependent', 'Left lateral Sims', 'Trendelenburg'],
    correct: 0,
    rationale:
      'Prone positioning recruits dorsal alveoli and improves ventilation–perfusion matching in ARDS, improving oxygenation. It requires a trained team to protect the airway and lines during turning.',
  },
  {
    id: 'q21',
    category: 'phys',
    sub: 'Reduction of Risk Potential',
    difficulty: 2,
    type: 'sata',
    stem:
      'A nurse monitors a client with a closed head injury. Which findings suggest increasing intracranial pressure? Select all that apply.',
    options: [
      'Widening pulse pressure with bradycardia',
      'Projectile vomiting without nausea',
      'Restlessness progressing to lethargy',
      'Pupil that is sluggish to react to light',
      'Respiratory rate of 22 with clear lungs',
    ],
    correct: [0, 1, 2, 3],
    rationale:
      'Cushing triad (widening pulse pressure, bradycardia, irregular respirations), projectile vomiting, decreasing level of consciousness, and a sluggish or unequal pupil are classic signs of rising ICP. A mildly elevated respiratory rate with clear lungs is nonspecific.',
  },
  {
    id: 'q22',
    category: 'phys',
    sub: 'Physiological Adaptation',
    difficulty: 2,
    type: 'mc',
    stem: 'A child with sickle cell disease is admitted in vaso-occlusive crisis. Which intervention is the priority?',
    options: [
      'Apply cold compresses to painful joints',
      'IV fluids, oxygen, and scheduled opioid analgesia',
      'Encourage vigorous active range of motion',
      'Restrict fluids to prevent overload',
    ],
    correct: 1,
    rationale:
      'Hydration reduces blood viscosity and sickling, oxygen supports tissue perfusion, and around-the-clock analgesia manages severe pain. Cold constricts vessels and worsens sickling; heat is used instead.',
  },
  {
    id: 'q23',
    category: 'phys',
    sub: 'Reduction of Risk Potential',
    difficulty: 2,
    type: 'mc',
    stem:
      'A client receiving continuous enteral feeding has a gastric residual volume of 320 mL. What should the nurse do first?',
    options: [
      'Discard the residual and continue the feeding',
      'Hold the feeding, keep the head of bed elevated, and reassess in 1 hour',
      'Flush the tube with 60 mL of air',
      'Increase the feeding rate to clear the stomach',
    ],
    correct: 1,
    rationale:
      'A high residual signals delayed gastric emptying and aspiration risk. Hold the feeding, maintain the head of bed at 30–45 degrees, reassess, and notify the provider if residuals stay elevated. Aspirate is returned, not discarded, to preserve electrolytes.',
  },
  {
    id: 'q24',
    category: 'phys',
    sub: 'Physiological Adaptation',
    difficulty: 2,
    type: 'mc',
    stem:
      'A client arrives with diabetic ketoacidosis: glucose 642 mg/dL, pH 7.18, potassium 5.6 mEq/L. Which order does the nurse implement first?',
    options: [
      'IV 0.9% sodium chloride bolus',
      'IV sodium bicarbonate push',
      'Subcutaneous long-acting insulin',
      'Oral potassium supplement',
    ],
    correct: 0,
    rationale:
      'DKA management is fluids first: isotonic saline restores volume and perfusion, followed by a regular insulin infusion and potassium replacement as levels drop with insulin therapy. Bicarbonate is reserved for severe acidosis.',
  },
  {
    id: 'q25',
    category: 'phys',
    sub: 'Basic Care & Comfort',
    difficulty: 1,
    type: 'mc',
    stem: 'Which action best prevents pressure injury in an immobile client?',
    options: [
      'Massage reddened bony prominences',
      'Reposition at least every 2 hours and keep skin clean and dry',
      'Elevate the head of bed to 90 degrees continuously',
      'Use a donut-shaped cushion when sitting',
    ],
    correct: 1,
    rationale:
      'Frequent repositioning, moisture control, pressure-redistributing surfaces, and adequate protein intake prevent pressure injuries. Massaging reddened areas and donut cushions damage tissue and increase pressure.',
  },
  {
    id: 'q26',
    category: 'phys',
    sub: 'Reduction of Risk Potential',
    difficulty: 3,
    type: 'matrix',
    stem:
      'For each assessment finding, indicate whether it is consistent with early sepsis or with hypovolemic shock from hemorrhage.',
    caseNote:
      'ED triage: 74-year-old from a long-term care facility, indwelling catheter for 3 weeks. Temp 38.9°C, HR 118, BP 92/48, RR 26, warm flushed skin, confusion, lactate 3.4 mmol/L, WBC 18,200.',
    cols: ['Sepsis', 'Hemorrhage'],
    rows: [
      { label: 'Warm, flushed skin with bounding pulse', correct: 0 },
      { label: 'Cool, clammy skin with thready pulse', correct: 1 },
      { label: 'Temperature 38.9°C with WBC 18,200', correct: 0 },
      { label: 'Hemoglobin dropping from 12.8 to 7.9 g/dL', correct: 1 },
      { label: 'Serum lactate 3.4 mmol/L with new confusion', correct: 0 },
    ],
    rationale:
      'Early (warm) sepsis produces vasodilation: warm flushed skin, fever, leukocytosis, and elevated lactate with altered mentation. Hemorrhagic shock produces compensatory vasoconstriction — cool clammy skin, thready pulse — plus a falling hemoglobin.',
  },
  {
    id: 'q27',
    category: 'phys',
    sub: 'Basic Care & Comfort',
    difficulty: 2,
    type: 'mc',
    stem:
      'Fifteen minutes into a unit of packed red blood cells the client reports chills, low back pain, and has a temperature rise of 1.5°C. What is the nurse’s first action?',
    options: [
      'Slow the transfusion and give acetaminophen',
      'Stop the transfusion and infuse 0.9% sodium chloride with new tubing',
      'Obtain a urine specimen for hemoglobin',
      'Document the reaction and continue monitoring',
    ],
    correct: 1,
    rationale:
      'These are signs of an acute hemolytic transfusion reaction. Stop the blood immediately, maintain IV access with normal saline using new tubing, then notify the provider and blood bank and return the unit with a urine specimen.',
  },
  // ---------------- PSYCHOSOCIAL ----------------
  {
    id: 'q28',
    category: 'psych',
    sub: 'Therapeutic Communication',
    difficulty: 1,
    type: 'mc',
    stem:
      'A client scheduled for a mastectomy says, "I do not know how I will face my family after this." Which response is most therapeutic?',
    options: [
      'Your family will love you no matter what happens.',
      'Tell me more about what worries you when you think about facing them.',
      'Most women adjust well after this surgery.',
      'Why would you feel that way about your own family?',
    ],
    correct: 1,
    rationale:
      'Open-ended exploration invites the client to express feelings and keeps the focus on her experience. False reassurance, generalizations, and "why" questions block communication and imply the feeling is unjustified.',
  },
  {
    id: 'q29',
    category: 'psych',
    sub: 'Mental Health Concepts',
    difficulty: 2,
    type: 'mc',
    stem: 'A client in an acute manic episode is not eating. Which nursing intervention is most appropriate?',
    options: [
      'Insist the client sit at the table for 30 minutes each meal',
      'Provide high-calorie finger foods and fluids the client can carry',
      'Withhold snacks until the client finishes a full meal',
      'Serve meals in a stimulating group setting',
    ],
    correct: 1,
    rationale:
      'Hyperactive clients cannot sit long enough to complete a meal, so portable high-calorie finger foods and frequent fluids meet nutritional needs. Reduce environmental stimulation rather than increasing it.',
  },
  {
    id: 'q30',
    category: 'psych',
    sub: 'Mental Health Concepts',
    difficulty: 3,
    type: 'mc',
    stem:
      'A client with anorexia nervosa is admitted with a BMI of 14.5. Which assessment finding requires immediate intervention?',
    options: [
      'Refusal to eat dessert at lunch',
      'Serum potassium of 2.6 mEq/L with irregular pulse',
      'Fine downy hair on the arms',
      'Statement that "I still look heavy"',
    ],
    correct: 1,
    rationale:
      'Electrolyte imbalance with dysrhythmia is the leading cause of death in eating disorders, so hypokalemia with an irregular pulse takes priority. Distorted body image and lanugo are expected findings addressed over time.',
  },
  {
    id: 'q31',
    category: 'psych',
    sub: 'Coping & Adaptation',
    difficulty: 2,
    type: 'mc',
    stem:
      'A client states, "Everyone would be better off without me." Which response should the nurse make first?',
    options: [
      'Are you thinking about killing yourself?',
      'You have so many people who care about you.',
      'Let us talk about something more positive.',
      'I will note that in your chart for the provider.',
    ],
    correct: 0,
    rationale:
      'Asking directly about suicidal intent is safe, expected practice — it does not plant the idea and it establishes lethality risk so protective measures (one-to-one observation, environmental safety) can begin at once.',
  },
  {
    id: 'q32',
    category: 'psych',
    sub: 'Coping & Adaptation',
    difficulty: 2,
    type: 'sata',
    stem:
      'A client admitted 24 hours ago is being monitored for alcohol withdrawal. Which findings should the nurse report? Select all that apply.',
    options: [
      'Blood pressure 168/94 with heart rate 112',
      'Coarse tremor of both hands',
      'Visual hallucinations of insects on the wall',
      'Sleeping 7 uninterrupted hours',
      'Diaphoresis with reported nausea',
    ],
    correct: [0, 1, 2, 4],
    rationale:
      'Autonomic hyperactivity, tremor, perceptual disturbance, and diaphoresis are withdrawal signs scored on the CIWA-Ar and treated with benzodiazepines plus thiamine. Restful sleep is a reassuring finding.',
  },
  // ---------------- SAFE & EFFECTIVE CARE ----------------
  {
    id: 'q33',
    category: 'safe',
    sub: 'Delegation & Prioritization',
    difficulty: 2,
    type: 'mc',
    stem:
      'Which task is appropriate for the registered nurse to delegate to an unlicensed assistive personnel?',
    options: [
      'Assisting a stable client who had a hip replacement 3 days ago to the chair',
      'Teaching a newly diagnosed diabetic to self-inject insulin',
      'Assessing a new admission’s wound drainage',
      'Adjusting the rate of a heparin infusion',
    ],
    correct: 0,
    rationale:
      'UAP may perform standardized tasks with predictable outcomes for stable clients, such as transfers, hygiene, and vital signs. Assessment, teaching, evaluation, and IV medication titration remain with the RN.',
  },
  {
    id: 'q34',
    category: 'safe',
    sub: 'Delegation & Prioritization',
    difficulty: 3,
    type: 'mc',
    stem: 'The nurse receives report on four clients. Which client should the nurse assess first?',
    options: [
      'A client with a 2-day-old colostomy asking about diet',
      'A client after thyroidectomy reporting a tight feeling in the throat',
      'A client with pneumonia and an oral temperature of 38.2°C',
      'A client with a hemoglobin A1C of 9.1% due for teaching',
    ],
    correct: 1,
    rationale:
      'A sensation of throat tightness after thyroidectomy suggests hematoma or swelling that can obstruct the airway — an airway emergency. Use ABC and the concept of unstable versus expected findings to prioritize.',
  },
  {
    id: 'q35',
    category: 'safe',
    sub: 'Safety & Infection Control',
    difficulty: 1,
    type: 'mc',
    stem: 'Which precautions does the nurse implement for a client admitted with suspected pulmonary tuberculosis?',
    options: [
      'Contact precautions in a private room',
      'Droplet precautions with a surgical mask',
      'Airborne precautions, negative-pressure room, and N95 respirator',
      'Standard precautions only',
    ],
    correct: 2,
    rationale:
      'Tuberculosis spreads by small airborne droplet nuclei, requiring a negative-pressure (airborne isolation) room and a fit-tested N95 for staff. The client wears a surgical mask when transported out of the room.',
  },
  {
    id: 'q36',
    category: 'safe',
    sub: 'Safety & Infection Control',
    difficulty: 2,
    type: 'sata',
    stem:
      'A client has Clostridioides difficile–associated diarrhea. Which nursing actions are indicated? Select all that apply.',
    options: [
      'Perform hand hygiene with soap and water',
      'Use alcohol-based hand rub as the primary method',
      'Place the client on contact precautions',
      'Dedicate equipment to the client’s room',
      'Clean surfaces with a bleach-based disinfectant',
    ],
    correct: [0, 2, 3, 4],
    rationale:
      'C. difficile spores resist alcohol, so hand hygiene must use soap and water with friction. Contact precautions, dedicated equipment, and sporicidal (bleach) cleaning are all required to stop transmission.',
  },
  {
    id: 'q37',
    category: 'safe',
    sub: 'Management of Care',
    difficulty: 2,
    type: 'mc',
    stem: 'What is the nurse’s primary responsibility regarding informed consent for surgery?',
    options: [
      'Explain the surgical risks and alternatives',
      'Witness the client’s signature and verify understanding',
      'Decide whether the client is competent to consent',
      'Obtain consent from the family instead of the client',
    ],
    correct: 1,
    rationale:
      'The provider performing the procedure explains risks, benefits, and alternatives. The nurse witnesses the signature, confirms the client’s understanding is voluntary, and notifies the provider if the client has unanswered questions.',
  },
  {
    id: 'q38',
    category: 'safe',
    sub: 'Safety & Infection Control',
    difficulty: 2,
    type: 'mc',
    stem: 'Which statement about the use of physical restraints is correct?',
    options: [
      'Restraints may be applied for staff convenience during busy shifts',
      'A PRN order for restraints is acceptable',
      'Less restrictive alternatives must be tried and documented first',
      'Restrained clients are assessed once per shift',
    ],
    correct: 2,
    rationale:
      'Restraints are a last resort: alternatives must be attempted and documented, a time-limited provider order is required (never PRN), and the client needs frequent assessment of circulation, skin, elimination, and release with range of motion.',
  },
  {
    id: 'q39',
    category: 'safe',
    sub: 'Safety & Infection Control',
    difficulty: 1,
    type: 'mc',
    stem: 'A fire starts in a client’s trash can. Using the RACE acronym, what does the nurse do first?',
    options: [
      'Activate the fire alarm',
      'Rescue clients in immediate danger',
      'Confine the fire by closing doors',
      'Extinguish the fire with an extinguisher',
    ],
    correct: 1,
    rationale:
      'RACE order is Rescue, Alarm, Confine, Extinguish. Clients in immediate danger are moved first. Extinguisher use follows PASS: Pull, Aim, Squeeze, Sweep.',
  },
  {
    id: 'q40',
    category: 'safe',
    sub: 'Management of Care',
    difficulty: 3,
    type: 'mc',
    stem:
      'During a mass casualty event using disaster triage, which client receives a red (immediate) tag?',
    options: [
      'A client with a closed femur fracture and stable vital signs',
      'A client with a tension pneumothorax and respiratory distress',
      'A client with fixed, dilated pupils and agonal respirations',
      'A client with superficial abrasions who is ambulatory',
    ],
    correct: 1,
    rationale:
      'Red (immediate) tags go to clients with life-threatening but survivable injuries needing care within an hour — such as tension pneumothorax. Stable fractures are yellow, ambulatory minor injuries are green, and expectant injuries are black.',
  },
];

export function buildPool({ cats = [], includeNGN = true, pharmOnly = false, mcOnly = false } = {}) {
  return ALL_QUESTIONS.filter((q) => {
    if (pharmOnly && q.category !== 'pharm') return false;
    if (mcOnly && q.type !== 'mc') return false;
    if (!includeNGN && q.type !== 'mc') return false;
    if (cats && cats.length > 0 && !cats.includes(q.category)) return false;
    return true;
  });
}

export function nextAdaptive(pool, usedIds = [], ability = 2) {
  const avail = (pool || []).filter((q) => !usedIds.includes(q.id));
  if (avail.length === 0) return null;
  const target = Math.max(1, Math.min(3, Math.round(Number.isFinite(ability) ? ability : 2)));
  const sorted = [...avail].sort(
    (a, b) => Math.abs((a.difficulty || 2) - target) - Math.abs((b.difficulty || 2) - target) || Math.random() - 0.5
  );
  const band = sorted.slice(0, Math.min(4, sorted.length));
  return band[Math.floor(Math.random() * band.length)] || sorted[0];
}

export function gradeQuestion(q, selected) {
  if (!q) return false;
  if (q.type === 'mc') return selected === q.correct;
  if (q.type === 'sata') {
    const s = [...(selected || [])].sort((a, b) => a - b);
    const c = [...(q.correct || [])].sort((a, b) => a - b);
    return s.length > 0 && s.length === c.length && s.every((v, i) => v === c[i]);
  }
  if (q.type === 'matrix') {
    const rows = q.rows || [];
    return rows.length > 0 && rows.every((r, i) => (selected || [])[i] === r.correct);
  }
  return false;
}

export function typeLabel(type) {
  if (type === 'sata') return 'Select All That Apply';
  if (type === 'matrix') return 'NGN · Matrix Grid';
  return 'Multiple Choice';
}

export const LEADERBOARD = [
  { id: 'l1', name: 'Maya R.', school: 'Chamberlain', score: 41, avatar: 'https://picsum.photos/seed/maya/120/120' },
  { id: 'l2', name: 'Devon P.', school: 'UT Austin', score: 37, avatar: 'https://picsum.photos/seed/devon/120/120' },
  { id: 'l3', name: 'Aisha K.', school: 'Rutgers', score: 33, avatar: 'https://picsum.photos/seed/aisha/120/120' },
  { id: 'l4', name: 'Colin M.', school: 'Galen College', score: 28, avatar: 'https://picsum.photos/seed/colin/120/120' },
  { id: 'l5', name: 'Priya S.', school: 'Nightingale', score: 24, avatar: 'https://picsum.photos/seed/priya/120/120' },
  { id: 'l6', name: 'Jordan T.', school: 'ASU Edson', score: 21, avatar: 'https://picsum.photos/seed/jordan/120/120' },
];
