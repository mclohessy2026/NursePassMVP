import React, { useCallback, useRef, useState } from 'react';
import {
  FlatList,
  KeyboardAvoidingView,
  Platform,
  Pressable,
  StyleSheet,
  Text,
  TextInput,
  View,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useSafeAreaInsets } from 'react-native-safe-area-context';

import TopBar from '../components/TopBar';
import { Press, R, S, Tag, useTokens } from '../components/ui';
import { getTutorReply } from '../data/tutor';
import { useApp } from '../store/AppContext';

const QUICK_PROMPTS = [
  'Explain digoxin toxicity',
  'How do I prioritize 4 clients?',
  'ABG interpretation',
  'Isolation precautions',
];

export default function TutorScreen() {
  const insets = useSafeAreaInsets();
  const { bg, surface, text, muted, border, accent, ink } = useTokens();
  const { chat = [], addChat, clearChat } = useApp() || {};
  const listRef = useRef(null);
  const [input, setInput] = useState('');
  const [thinking, setThinking] = useState(false);

  const submit = useCallback(
    (raw) => {
      const trimmed = String(raw ?? input).trim();
      if (!trimmed || thinking) return;
      addChat?.('user', trimmed);
      setInput('');
      setThinking(true);

      setTimeout(() => {
        addChat?.('tutor', getTutorReply(trimmed));
        setThinking(false);
        requestAnimationFrame(() => listRef.current?.scrollToEnd({ animated: true }));
      }, 450);
    },
    [addChat, input, thinking]
  );

  const renderItem = ({ item }) => {
    const mine = item.role === 'user';
    return (
      <View style={[styles.row, { justifyContent: mine ? 'flex-end' : 'flex-start' }]}>
        {!mine ? (
          <View style={[styles.avatar, { backgroundColor: `${accent}18` }]}>
            <Ionicons name="sparkles" size={15} color={accent} />
          </View>
        ) : null}
        <View
          style={[
            styles.bubble,
            {
              backgroundColor: mine ? ink : surface,
              borderColor: mine ? ink : border,
            },
          ]}
        >
          {!mine ? <Text style={{ color: accent, fontSize: 10.5, fontWeight: '900', marginBottom: 5 }}>ADA · NURSEPASS TUTOR</Text> : null}
          <Text style={{ color: mine ? '#fff' : text, fontSize: 14, lineHeight: 20 }}>{item.text}</Text>
        </View>
      </View>
    );
  };

  return (
    <KeyboardAvoidingView
      style={{ flex: 1, backgroundColor: bg, paddingTop: insets.top }}
      behavior={Platform.OS === 'ios' ? 'padding' : undefined}
      keyboardVerticalOffset={Platform.OS === 'ios' ? 10 : 0}
    >
      <TopBar
        title="Tutor"
        subtitle="Ada explains concepts the way NCLEX-style questions test them"
        rightIcon="trash-outline"
        rightLabel="CLEAR"
        onRight={() => clearChat?.()}
      />

      <View style={{ paddingHorizontal: S.md, paddingTop: 4 }}>
        <View style={{ flexDirection: 'row', alignItems: 'center' }}>
          <Tag label="Study support" color={accent} />
          <Text style={{ color: muted, fontSize: 10.5, marginLeft: 8, flex: 1 }}>Educational only — not patient-care guidance.</Text>
        </View>
      </View>

      <FlatList
        ref={listRef}
        data={chat}
        keyExtractor={(item) => String(item.id)}
        renderItem={renderItem}
        contentContainerStyle={{ padding: S.md, paddingBottom: 12 }}
        onContentSizeChange={() => listRef.current?.scrollToEnd({ animated: true })}
        ListFooterComponent={
          <View>
            {thinking ? (
              <View style={[styles.row, { justifyContent: 'flex-start' }]}>
                <View style={[styles.avatar, { backgroundColor: `${accent}18` }]}>
                  <Ionicons name="ellipsis-horizontal" size={15} color={accent} />
                </View>
                <View style={[styles.bubble, { backgroundColor: surface, borderColor: border }]}>
                  <Text style={{ color: muted, fontSize: 13 }}>Ada is thinking…</Text>
                </View>
              </View>
            ) : null}

            {chat.length <= 1 ? (
              <View style={{ marginTop: 6 }}>
                <Text style={{ color: muted, fontSize: 11, fontWeight: '900', marginBottom: 8 }}>TRY A PROMPT</Text>
                <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 8 }}>
                  {QUICK_PROMPTS.map((prompt) => (
                    <Press key={prompt} onPress={() => submit(prompt)} scaleTo={0.96}>
                      <View style={{ paddingHorizontal: 11, paddingVertical: 8, borderRadius: 999, borderWidth: 1, borderColor: border, backgroundColor: surface }}>
                        <Text style={{ color: text, fontSize: 11.5, fontWeight: '700' }}>{prompt}</Text>
                      </View>
                    </Press>
                  ))}
                </View>
              </View>
            ) : null}
          </View>
        }
      />

      <View style={{ borderTopWidth: 1, borderTopColor: border, paddingHorizontal: S.md, paddingTop: 10, paddingBottom: Math.max(insets.bottom, 12), backgroundColor: surface }}>
        <View style={{ flexDirection: 'row', alignItems: 'flex-end', gap: 10 }}>
          <TextInput
            style={{ flex: 1, minHeight: 44, maxHeight: 110, borderRadius: 22, backgroundColor: bg, color: text, paddingHorizontal: 16, paddingVertical: 11, fontSize: 14 }}
            placeholder="Ask about a drug, lab, disease, or priority question…"
            placeholderTextColor={muted}
            value={input}
            onChangeText={setInput}
            onSubmitEditing={() => submit()}
            returnKeyType="send"
            multiline
          />
          <Pressable
            accessibilityRole="button"
            accessibilityLabel="Send message"
            disabled={!input.trim() || thinking}
            onPress={() => submit()}
            style={{ width: 44, height: 44, borderRadius: 22, backgroundColor: accent, opacity: !input.trim() || thinking ? 0.45 : 1, alignItems: 'center', justifyContent: 'center' }}
          >
            <Ionicons name="send" size={18} color="#fff" />
          </Pressable>
        </View>
      </View>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  row: { flexDirection: 'row', alignItems: 'flex-end', marginBottom: 14 },
  avatar: { width: 30, height: 30, borderRadius: 15, alignItems: 'center', justifyContent: 'center', marginRight: 8 },
  bubble: { maxWidth: '82%', borderRadius: R.lg, borderWidth: 1, paddingHorizontal: 14, paddingVertical: 11 },
});
