import React, { useMemo } from 'react';
import { ScrollView, Text, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useSafeAreaInsets } from 'react-native-safe-area-context';

import Ring from '../components/Ring';
import { Card, PrimaryButton, R, S, Tag, accuracyColor, useTokens } from '../components/ui';
import { categoryByKey, typeLabel } from '../data/questions';

function formatTime(seconds) {
  const s = Math.max(0, Number(seconds) || 0);
  const m = Math.floor(s / 60);
  return `${m}:${`${Math.floor(s % 60)}`.padStart(2, '0')}`;
}

function answerText(question, selection, correct = false) {
  if (!question) return '—';
  const value = correct ? question.correct : selection;
  if (question.type === 'mc') {
    return typeof value === 'number' ? question.options?.[value] || `Option ${value + 1}` : 'No answer';
  }
  if (question.type === 'sata') {
    const indexes = Array.isArray(value) ? value : [];
    return indexes.length ? indexes.map((i) => question.options?.[i]).filter(Boolean).join(' • ') : 'No answer';
  }
  if (question.type === 'matrix') {
    const rows = question.rows || [];
    const cols = question.cols || [];
    const picks = correct ? rows.map((r) => r.correct) : Array.isArray(value) ? value : [];
    return rows
      .map((row, i) => `${row.label}: ${typeof picks[i] === 'number' ? cols[picks[i]] || '—' : 'No answer'}`)
      .join('\n');
  }
  return '—';
}

export default function ResultScreen({ route, navigation }) {
  const insets = useSafeAreaInsets();
  const { bg, surface, text, muted, border, accent, ac } = useTokens();
  const { entries = [], seconds = 0, cfg = {} } = route?.params || {};
  const total = entries.length;
  const correct = entries.filter((e) => e?.correct).length;
  const pct = total > 0 ? Math.round((correct / total) * 100) : 0;
  const wrong = useMemo(() => entries.filter((e) => !e?.correct), [entries]);
  const message = pct >= 85 ? 'Strong session' : pct >= 70 ? 'Good progress' : pct >= 55 ? 'Keep building' : 'Review and repeat';
  const scoreColor = accuracyColor(pct);

  const retry = () => navigation.replace('Quiz', { ...cfg, ts: Date.now() });

  return (
    <View style={{ flex: 1, backgroundColor: bg }}>
      <ScrollView
        showsVerticalScrollIndicator={false}
        contentContainerStyle={{ paddingTop: insets.top + S.lg, paddingHorizontal: S.md, paddingBottom: S.xl }}
      >
        <View style={{ alignItems: 'center' }}>
          <Tag label="Session complete" color={accent} />
          <View style={{ marginTop: S.lg }}>
            <Ring size={172} strokeWidth={15} progress={total ? correct / total : 0} color={scoreColor} trackColor={border}>
              <Text style={{ color: text, fontSize: 34, fontWeight: '900', letterSpacing: -1 }}>{pct}%</Text>
              <Text style={{ color: muted, fontSize: 12.5, fontWeight: '700' }}>{correct}/{total} correct</Text>
            </Ring>
          </View>
          <Text style={{ color: text, fontSize: 24, fontWeight: '900', marginTop: S.md }}>{message}</Text>
          <Text style={{ color: muted, fontSize: 13, marginTop: 5 }}>
            {formatTime(seconds)} elapsed · {wrong.length} item{wrong.length === 1 ? '' : 's'} to review
          </Text>
        </View>

        <View style={{ flexDirection: 'row', gap: 10, marginTop: S.lg }}>
          <Card style={{ flex: 1, padding: 14, alignItems: 'center' }}>
            <Ionicons name="checkmark-circle" size={22} color={ac(2)} />
            <Text style={{ color: text, fontSize: 18, fontWeight: '900', marginTop: 5 }}>{correct}</Text>
            <Text style={{ color: muted, fontSize: 10.5, fontWeight: '800' }}>CORRECT</Text>
          </Card>
          <Card style={{ flex: 1, padding: 14, alignItems: 'center' }}>
            <Ionicons name="close-circle" size={22} color="#D9455A" />
            <Text style={{ color: text, fontSize: 18, fontWeight: '900', marginTop: 5 }}>{wrong.length}</Text>
            <Text style={{ color: muted, fontSize: 10.5, fontWeight: '800' }}>REVIEW</Text>
          </Card>
          <Card style={{ flex: 1, padding: 14, alignItems: 'center' }}>
            <Ionicons name="time" size={22} color={ac(3)} />
            <Text style={{ color: text, fontSize: 18, fontWeight: '900', marginTop: 5 }}>{formatTime(seconds)}</Text>
            <Text style={{ color: muted, fontSize: 10.5, fontWeight: '800' }}>TIME</Text>
          </Card>
        </View>

        {wrong.length > 0 ? (
          <View style={{ marginTop: S.xl }}>
            <Text style={{ color: text, fontSize: 19, fontWeight: '900', marginBottom: 4 }}>Review missed items</Text>
            <Text style={{ color: muted, fontSize: 13, marginBottom: S.md }}>Read the rationale before starting another set.</Text>
            {wrong.map((entry, index) => {
              const q = entry.question || entry;
              const cat = categoryByKey(entry.category || q.category);
              return (
                <Card key={`${entry.id || q.id}-${index}`} style={{ padding: S.md, marginBottom: S.md }}>
                  <View style={{ flexDirection: 'row', alignItems: 'center', marginBottom: 10 }}>
                    <Tag label={typeLabel(entry.type || q.type)} color={ac(cat.colorIndex || 0)} />
                    <Text style={{ color: muted, fontSize: 11.5, marginLeft: 8, flex: 1 }} numberOfLines={1}>
                      {entry.sub || q.sub}
                    </Text>
                  </View>
                  <Text style={{ color: text, fontSize: 15.5, fontWeight: '800', lineHeight: 22 }}>{entry.stem || q.stem}</Text>

                  <View style={{ marginTop: 14, padding: 12, borderRadius: R.md, backgroundColor: '#D9455A12' }}>
                    <Text style={{ color: '#D9455A', fontSize: 11, fontWeight: '900' }}>YOUR ANSWER</Text>
                    <Text style={{ color: text, fontSize: 12.5, lineHeight: 18, marginTop: 5 }}>{answerText(q, entry.selected, false)}</Text>
                  </View>
                  <View style={{ marginTop: 8, padding: 12, borderRadius: R.md, backgroundColor: `${ac(2)}12` }}>
                    <Text style={{ color: ac(2), fontSize: 11, fontWeight: '900' }}>CORRECT ANSWER</Text>
                    <Text style={{ color: text, fontSize: 12.5, lineHeight: 18, marginTop: 5 }}>{answerText(q, null, true)}</Text>
                  </View>
                  <Text style={{ color: text, fontSize: 13.5, lineHeight: 20, marginTop: 14 }}>{entry.rationale || q.rationale}</Text>
                </Card>
              );
            })}
          </View>
        ) : (
          <Card style={{ padding: S.lg, marginTop: S.xl, alignItems: 'center' }}>
            <Ionicons name="sparkles" size={30} color={accent} />
            <Text style={{ color: text, fontSize: 16, fontWeight: '900', marginTop: 8 }}>No missed items</Text>
            <Text style={{ color: muted, fontSize: 13, textAlign: 'center', marginTop: 4 }}>Nice work. Increase the difficulty with another adaptive set.</Text>
          </Card>
        )}

        <View style={{ gap: 10, marginTop: S.lg }}>
          <PrimaryButton size="lg" icon="reload" label="Try another set" onPress={retry} />
          <PrimaryButton size="lg" variant="outline" icon="arrow-back" label="Back to Practice" onPress={() => navigation.navigate('PracticeHome')} />
        </View>
      </ScrollView>
    </View>
  );
}
