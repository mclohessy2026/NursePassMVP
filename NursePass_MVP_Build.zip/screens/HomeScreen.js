import React, { useMemo } from 'react';
import { Dimensions, ScrollView, Text, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { LinearGradient } from 'expo-linear-gradient';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useNavigation } from '@react-navigation/native';
import { AnimatedNumber, AppImage, FadeInView, Sparkline } from '../ui/kit';
import Ring from '../components/Ring';
import TopBar from '../components/TopBar';
import { Press, R, S, Shimmer, Tag, accuracyColor, cardShadow, useTokens } from '../components/ui';
import { daysUntil, prettyDate, useApp } from '../store/AppContext';
import { BANK_SIZE } from '../data/questions';

const DAY_LETTERS = ['S', 'M', 'T', 'W', 'T', 'F', 'S'];
const W = Dimensions.get('window').width;

function LaunchTile({ image, title, caption, icon, color, tall, onPress, delay }) {
  const { surface } = useTokens();
  return (
    <FadeInView delay={delay} style={{ flex: 1 }}>
      <Press onPress={onPress} scaleTo={0.97} haptic="medium">
        <View
          style={{
            height: tall ? 236 : 110,
            borderRadius: R.lg,
            overflow: 'hidden',
            backgroundColor: surface,
            ...cardShadow,
          }}
        >
          <AppImage source={image} style={{ position: 'absolute', width: '100%', height: '100%' }} />
          <LinearGradient
            colors={['rgba(11,22,36,0.20)', 'rgba(11,22,36,0.88)']}
            style={{ flex: 1, justifyContent: 'flex-end', padding: 14 }}
          >
            <View
              style={{
                width: 32,
                height: 32,
                borderRadius: 11,
                backgroundColor: color,
                alignItems: 'center',
                justifyContent: 'center',
                marginBottom: tall ? 10 : 6,
              }}
            >
              <Ionicons name={icon} size={18} color="#fff" />
            </View>
            <Text style={{ color: '#fff', fontSize: tall ? 20 : 15, fontWeight: '900', letterSpacing: -0.3 }}>
              {title}
            </Text>
            <Text style={{ color: 'rgba(255,255,255,0.78)', fontSize: tall ? 13 : 11.5, marginTop: 2 }} numberOfLines={2}>
              {caption}
            </Text>
          </LinearGradient>
        </View>
      </Press>
    </FadeInView>
  );
}

export default function HomeScreen() {
  const insets = useSafeAreaInsets();
  const navigation = useNavigation();
  const { text, muted, surface, border, accent, ac, ink, bg } = useTokens();
  const app = useApp() || {};
  const {
    ready = false,
    readiness = 0,
    accuracy = 0,
    answered = 0,
    streak = 0,
    bestStreak = 0,
    history = [],
    weakSubs = [],
    sessions = [],
    tasks = [],
    examDate,
    plan,
    trial,
    toggleTask,
  } = app;

  const trend = useMemo(() => (history || []).slice(-14).map((h) => h?.score || 0), [history]);
  const examIn = daysUntil(examDate);
  const todayIdx = new Date().getDay();

  const streakDays = useMemo(() => {
    const out = [];
    for (let i = 6; i >= 0; i--) {
      const d = new Date();
      d.setDate(d.getDate() - i);
      const iso = `${d.getFullYear()}-${`${d.getMonth() + 1}`.padStart(2, '0')}-${`${d.getDate()}`.padStart(2, '0')}`;
      const rec = (history || []).find((h) => h?.date === iso);
      out.push({
        letter: DAY_LETTERS[d.getDay()] || '·',
        active: (rec?.answered || 0) > 0,
        isToday: d.getDay() === todayIdx && i === 0,
        count: rec?.answered || 0,
      });
    }
    return out;
  }, [history, todayIdx]);

  const doneTasks = (tasks || []).filter((t) => t?.done).length;
  const band =
    answered < 20 ? (answered > 0 ? 'Building your baseline' : 'Start your baseline') : readiness >= 80 ? 'Strong study trend' : readiness >= 70 ? 'On track in practice' : readiness >= 60 ? 'Needs targeted review' : 'Build foundations';
  const bandColor = accuracyColor(readiness);

  const goPractice = (preset) =>
    navigation.navigate('Practice', { screen: 'PracticeHome', params: { preset, ts: Date.now() } });

  if (!ready) {
    return (
      <View style={{ flex: 1, backgroundColor: bg, paddingTop: insets.top + S.md }}>
        <View style={{ paddingHorizontal: S.md }}>
          <Shimmer width={180} height={26} radius={10} />
          <Shimmer width={'100%'} height={190} radius={24} style={{ marginTop: S.lg }} />
          <Shimmer width={'100%'} height={70} radius={20} style={{ marginTop: S.md }} />
          <View style={{ flexDirection: 'row', marginTop: S.md }}>
            <Shimmer width={(W - 44) / 2} height={236} radius={20} />
            <View style={{ width: 12 }} />
            <View>
              <Shimmer width={(W - 44) / 2} height={110} radius={20} />
              <Shimmer width={(W - 44) / 2} height={110} radius={20} style={{ marginTop: 16 }} />
            </View>
          </View>
        </View>
      </View>
    );
  }

  return (
    <View style={{ flex: 1, backgroundColor: bg }}>
      <ScrollView
        contentContainerStyle={{ paddingTop: insets.top + S.sm, paddingBottom: S.xl + 60 }}
        showsVerticalScrollIndicator={false}
      >
        <TopBar
          logo
          title="NursePass"
          subtitle={`NCLEX-RN · ${BANK_SIZE.toLocaleString()} item bank`}
          rightIcon={plan ? 'shield-checkmark' : 'sparkles'}
          rightLabel={trial ? 'TRIAL' : plan ? 'PRO' : 'UPGRADE'}
          rightColor={accent}
          onRight={() => navigation.navigate('Pricing')}
        />

        {/* READINESS HERO */}
        <FadeInView>
          <View
            style={{
              marginHorizontal: S.md,
              borderRadius: R.xl,
              overflow: 'hidden',
              backgroundColor: ink,
              ...cardShadow,
            }}
          >
            <LinearGradient colors={[ink, '#0D1B2C']} style={{ padding: S.md + 4 }}>
              <View style={{ flexDirection: 'row', alignItems: 'center' }}>
                <Ring size={118} stroke={11} value={readiness / 100} color={accent} track="rgba(255,255,255,0.14)">
                  <View style={{ alignItems: 'center' }}>
                    <AnimatedNumber
                      value={readiness}
                      style={{ color: '#fff', fontSize: 34, fontWeight: '900', letterSpacing: -1.5 }}
                    />
                    <Text style={{ color: 'rgba(255,255,255,0.6)', fontSize: 10, fontWeight: '800', letterSpacing: 1 }}>
                      READINESS
                    </Text>
                  </View>
                </Ring>

                <View style={{ flex: 1, marginLeft: S.md }}>
                  <Tag label={band} color={bandColor} tone="solid" />
                  <Text style={{ color: '#fff', fontSize: 15, fontWeight: '800', marginTop: 10, lineHeight: 21 }}>
                    {examDate ? (examIn > 0 ? `${examIn} days until your exam` : 'Exam day is here') : 'Add your NCLEX exam date'}
                  </Text>
                  <Press onPress={() => navigation.navigate('Settings')} scaleTo={0.96}>
                    <Text style={{ color: 'rgba(255,255,255,0.62)', fontSize: 12.5, marginTop: 3 }}>
                      {examDate ? `Scheduled ${prettyDate(examDate)} · tap to change` : 'Tap to set your test date'}
                    </Text>
                  </Press>
                  <Press onPress={() => navigation.navigate('Readiness')} scaleTo={0.95} style={{ marginTop: 12 }}>
                    <View style={{ flexDirection: 'row', alignItems: 'center' }}>
                      <Text style={{ color: accent, fontWeight: '900', fontSize: 13 }}>View full analytics</Text>
                      <Ionicons name="arrow-forward" size={14} color={accent} style={{ marginLeft: 5 }} />
                    </View>
                  </Press>
                </View>
              </View>

              <View
                style={{
                  flexDirection: 'row',
                  marginTop: S.md,
                  paddingTop: S.md,
                  borderTopWidth: 1,
                  borderTopColor: 'rgba(255,255,255,0.12)',
                }}
              >
                {[
                  { label: 'Questions', value: answered, icon: 'documents' },
                  { label: 'Accuracy', value: accuracy, suffix: '%', icon: 'checkmark-done' },
                  { label: 'Day streak', value: streak, icon: 'flame' },
                ].map((m, i) => (
                  <View key={m.label} style={{ flex: 1, borderLeftWidth: i === 0 ? 0 : 1, borderLeftColor: 'rgba(255,255,255,0.12)', paddingLeft: i === 0 ? 0 : 12 }}>
                    <View style={{ flexDirection: 'row', alignItems: 'center' }}>
                      <Ionicons name={m.icon} size={13} color={ac(i + 2)} />
                      <Text style={{ color: 'rgba(255,255,255,0.55)', fontSize: 10.5, fontWeight: '800', marginLeft: 4, letterSpacing: 0.4 }}>
                        {m.label.toUpperCase()}
                      </Text>
                    </View>
                    <AnimatedNumber
                      value={m.value}
                      suffix={m.suffix || ''}
                      style={{ color: '#fff', fontSize: 21, fontWeight: '900', marginTop: 3, letterSpacing: -0.6 }}
                    />
                  </View>
                ))}
              </View>
            </LinearGradient>
          </View>
        </FadeInView>

        {/* STREAK RAIL */}
        <FadeInView delay={80}>
          <View
            style={{
              marginHorizontal: S.md,
              marginTop: S.md,
              backgroundColor: surface,
              borderRadius: R.lg,
              borderWidth: 1,
              borderColor: border,
              padding: S.md - 2,
              flexDirection: 'row',
              alignItems: 'center',
              ...cardShadow,
            }}
          >
            <View style={{ marginRight: 12, alignItems: 'center' }}>
              <Ionicons name="flame" size={22} color={accent} />
              <Text style={{ color: text, fontWeight: '900', fontSize: 13, marginTop: 2 }}>{streak}d</Text>
            </View>
            <View style={{ flex: 1, flexDirection: 'row', justifyContent: 'space-between' }}>
              {streakDays.map((d, i) => (
                <View key={`${d.letter}-${i}`} style={{ alignItems: 'center' }}>
                  <View
                    style={{
                      width: 30,
                      height: 30,
                      borderRadius: 11,
                      backgroundColor: d.active ? accent : 'rgba(22,38,58,0.05)',
                      borderWidth: d.isToday ? 2 : 0,
                      borderColor: ink,
                      alignItems: 'center',
                      justifyContent: 'center',
                    }}
                  >
                    {d.active ? (
                      <Ionicons name="checkmark" size={15} color="#fff" />
                    ) : (
                      <Text style={{ color: muted, fontSize: 11, fontWeight: '800' }}>{d.letter}</Text>
                    )}
                  </View>
                  <Text style={{ color: muted, fontSize: 9.5, marginTop: 4, fontWeight: '700' }}>{d.count || '–'}</Text>
                </View>
              ))}
            </View>
            <View style={{ marginLeft: 10, alignItems: 'flex-end' }}>
              <Text style={{ color: muted, fontSize: 10, fontWeight: '800' }}>BEST</Text>
              <Text style={{ color: text, fontSize: 15, fontWeight: '900' }}>{bestStreak}d</Text>
            </View>
          </View>
        </FadeInView>

        {/* LAUNCH GRID */}
        <View style={{ flexDirection: 'row', marginHorizontal: S.md, marginTop: S.md }}>
          <LaunchTile
            tall
            delay={120}
            image="https://images.unsplash.com/photo-1576091160550-2173dba999ef?w=800&q=80"
            title="Start practice"
            caption="Adaptive CAT engine · MC + NGN items with instant rationales"
            icon="play"
            color={accent}
            onPress={() => goPractice(null)}
          />
          <View style={{ width: 12 }} />
          <View style={{ flex: 1, justifyContent: 'space-between' }}>
            <LaunchTile
              delay={180}
              image="https://images.unsplash.com/photo-1587854692152-cbe660dbde88?w=800&q=80"
              title="Play a game"
              caption="Boss Battle · Speed · Survival"
              icon="game-controller"
              color={ac(5)}
              onPress={() => navigation.navigate('Games')}
            />
            <LaunchTile
              delay={240}
              image="https://images.unsplash.com/photo-1559839734-2b71ea197ec2?w=800&q=80"
              title="Ask Ada Tutor"
              caption="Clinical study explanations"
              icon="chatbubbles"
              color={ac(2)}
              onPress={() => navigation.navigate('Tutor')}
            />
          </View>
        </View>

        {/* TODAY PLAN */}
        <FadeInView delay={280}>
          <View
            style={{
              marginHorizontal: S.md,
              marginTop: S.lg,
              backgroundColor: surface,
              borderRadius: R.lg,
              borderWidth: 1,
              borderColor: border,
              padding: S.md,
              ...cardShadow,
            }}
          >
            <View style={{ flexDirection: 'row', alignItems: 'center', marginBottom: 12 }}>
              <Text style={{ color: text, fontSize: 16, fontWeight: '900', flex: 1 }}>Today’s plan</Text>
              <Text style={{ color: muted, fontSize: 12, fontWeight: '800' }}>
                {doneTasks}/{(tasks || []).length || 0} done
              </Text>
            </View>
            {(tasks || []).map((task) => (
              <Press
                key={task.id}
                onPress={() => toggleTask && toggleTask(task.id)}
                scaleTo={0.98}
                style={{ marginBottom: 6 }}
              >
                <View style={{ flexDirection: 'row', alignItems: 'center', paddingVertical: 7 }}>
                  <View
                    style={{
                      width: 24,
                      height: 24,
                      borderRadius: 8,
                      borderWidth: 1.5,
                      borderColor: task.done ? ac(2) : border,
                      backgroundColor: task.done ? ac(2) : 'transparent',
                      alignItems: 'center',
                      justifyContent: 'center',
                      marginRight: 12,
                    }}
                  >
                    {task.done ? <Ionicons name="checkmark" size={15} color="#fff" /> : null}
                  </View>
                  <Text
                    style={{
                      color: task.done ? muted : text,
                      fontSize: 14.5,
                      fontWeight: '600',
                      textDecorationLine: task.done ? 'line-through' : 'none',
                    }}
                  >
                    {task.label}
                  </Text>
                </View>
              </Press>
            ))}
          </View>
        </FadeInView>

        {/* WEAK SPOTS */}
        <View style={{ marginTop: S.lg, paddingHorizontal: S.md }}>
          <View style={{ flexDirection: 'row', alignItems: 'flex-end', marginBottom: S.md }}>
            <View style={{ flex: 1 }}>
              <Text style={{ color: text, fontSize: 18, fontWeight: '900', letterSpacing: -0.3 }}>Fix your weak spots</Text>
              <Text style={{ color: muted, fontSize: 13, marginTop: 2 }}>Lowest-scoring NCSBN subcategories</Text>
            </View>
          </View>
          {(weakSubs || []).slice(0, 3).map((sub, i) => (
            <FadeInView key={sub.name} delay={60 + i * 70}>
              <Press onPress={() => goPractice(sub.categoryKey)} scaleTo={0.985} style={{ marginBottom: S.sm }}>
                <View
                  style={{
                    flexDirection: 'row',
                    alignItems: 'center',
                    backgroundColor: surface,
                    borderRadius: R.md,
                    borderWidth: 1,
                    borderColor: border,
                    padding: 13,
                    ...cardShadow,
                  }}
                >
                  <View
                    style={{
                      width: 42,
                      height: 42,
                      borderRadius: 13,
                      backgroundColor: `${accuracyColor(sub.accuracy)}1F`,
                      alignItems: 'center',
                      justifyContent: 'center',
                      marginRight: 12,
                    }}
                  >
                    <Text style={{ color: accuracyColor(sub.accuracy), fontWeight: '900', fontSize: 14 }}>
                      {sub.accuracy}%
                    </Text>
                  </View>
                  <View style={{ flex: 1 }}>
                    <Text style={{ color: text, fontSize: 14.5, fontWeight: '800' }} numberOfLines={1}>
                      {sub.name}
                    </Text>
                    <Text style={{ color: muted, fontSize: 11.5, marginTop: 2 }}>
                      {sub.short} · {sub.answered} answered
                    </Text>
                  </View>
                  <Sparkline
                    data={makeSpark(sub.accuracy, i)}
                    color={accuracyColor(sub.accuracy)}
                    width={62}
                    height={26}
                  />
                  <Ionicons name="chevron-forward" size={18} color={muted} style={{ marginLeft: 6 }} />
                </View>
              </Press>
            </FadeInView>
          ))}
        </View>

        {/* RECENT ACTIVITY */}
        <View style={{ marginTop: S.lg, paddingHorizontal: S.md }}>
          <Text style={{ color: text, fontSize: 18, fontWeight: '900', letterSpacing: -0.3, marginBottom: S.md }}>
            Recent activity
          </Text>
          <View
            style={{
              backgroundColor: surface,
              borderRadius: R.lg,
              borderWidth: 1,
              borderColor: border,
              paddingHorizontal: S.md,
              ...cardShadow,
            }}
          >
            {(sessions || []).slice(0, 5).map((s, i) => {
              const acc = (s?.answered || 0) > 0 ? Math.round(((s.correct || 0) / s.answered) * 100) : 0;
              return (
                <View
                  key={s.id || i}
                  style={{
                    flexDirection: 'row',
                    alignItems: 'center',
                    paddingVertical: 14,
                    borderTopWidth: i === 0 ? 0 : 1,
                    borderTopColor: border,
                  }}
                >
                  <View style={{ width: 22, alignItems: 'center', marginRight: 10 }}>
                    <View style={{ width: 9, height: 9, borderRadius: 5, backgroundColor: ac(i) }} />
                    {i < Math.min(4, (sessions || []).length - 1) ? (
                      <View style={{ width: 1.5, flex: 1, minHeight: 14, backgroundColor: border, marginTop: 4 }} />
                    ) : null}
                  </View>
                  <View style={{ flex: 1 }}>
                    <Text style={{ color: text, fontSize: 14, fontWeight: '800' }}>{s.mode}</Text>
                    <Text style={{ color: muted, fontSize: 11.5, marginTop: 2 }}>
                      {prettyDate(s.date)} · {s.answered} items · {s.category}
                    </Text>
                  </View>
                  <Text style={{ color: accuracyColor(acc), fontWeight: '900', fontSize: 15 }}>{acc}%</Text>
                </View>
              );
            })}
            {(sessions || []).length === 0 ? (
              <View style={{ paddingVertical: S.lg, alignItems: 'center' }}>
                <Ionicons name="time-outline" size={26} color={muted} />
                <Text style={{ color: muted, fontSize: 13, marginTop: 8 }}>No sessions yet — start your first set.</Text>
              </View>
            ) : null}
          </View>
        </View>

        <FadeInView delay={120}>
          <Press onPress={() => navigation.navigate('Pricing')} scaleTo={0.98}>
            <View
              style={{
                marginHorizontal: S.md,
                marginTop: S.lg,
                borderRadius: R.lg,
                padding: S.md,
                backgroundColor: `${accent}12`,
                borderWidth: 1,
                borderColor: `${accent}40`,
                flexDirection: 'row',
                alignItems: 'center',
              }}
            >
              <Ionicons name="rocket" size={22} color={accent} />
              <View style={{ flex: 1, marginLeft: 12 }}>
                <Text style={{ color: text, fontWeight: '900', fontSize: 14.5 }}>
                  {trial ? `Free trial active until ${prettyDate(trial.endsOn)}` : `${BANK_SIZE} starter practice questions included`}
                </Text>
                <Text style={{ color: muted, fontSize: 12, marginTop: 2 }}>
                  {trial ? 'Compare plans before it ends' : 'Plans from $9.99 · 7-day free trial'}
                </Text>
              </View>
              <Ionicons name="chevron-forward" size={18} color={accent} />
            </View>
          </Press>
        </FadeInView>
      </ScrollView>
    </View>
  );
}

function makeSpark(acc, seed) {
  const base = Number.isFinite(acc) ? acc : 60;
  const out = [];
  for (let i = 0; i < 8; i++) {
    const wobble = Math.sin((i + seed) * 1.15) * 6 + (i - 4) * 0.9;
    out.push(Math.max(20, Math.min(100, Math.round(base + wobble))));
  }
  return out;
}
