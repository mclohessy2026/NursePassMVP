import React, { useMemo, useState } from 'react';
import { Alert, ScrollView, Text, TextInput, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useSafeAreaInsets } from 'react-native-safe-area-context';

import { Card, Press, PrimaryButton, R, S, useTokens } from '../components/ui';
import { dayKey, prettyDate, useApp } from '../store/AppContext';

function validIso(value) {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(value)) return false;
  const [y, m, d] = value.split('-').map(Number);
  const date = new Date(y, m - 1, d);
  return date.getFullYear() === y && date.getMonth() === m - 1 && date.getDate() === d;
}

export default function SettingsScreen({ navigation }) {
  const insets = useSafeAreaInsets();
  const { bg, surface, text, muted, border, accent, ac } = useTokens();
  const { examDate, setExamDate, resetProgress, answered = 0 } = useApp() || {};
  const [value, setValue] = useState(examDate || '');
  const [error, setError] = useState('');
  const preview = useMemo(() => (validIso(value) ? prettyDate(value) : ''), [value]);

  const save = () => {
    if (!value) {
      setExamDate?.(null);
      navigation.goBack();
      return;
    }
    if (!validIso(value)) {
      setError('Use YYYY-MM-DD, for example 2026-10-27.');
      return;
    }
    setError('');
    setExamDate?.(value);
    navigation.goBack();
  };

  const confirmReset = () => {
    Alert.alert(
      'Reset study progress?',
      'This clears practice history, readiness data, game stats, tasks, and your saved exam date on this device.',
      [
        { text: 'Cancel', style: 'cancel' },
        { text: 'Reset', style: 'destructive', onPress: () => resetProgress?.() },
      ]
    );
  };

  return (
    <View style={{ flex: 1, backgroundColor: bg, paddingTop: insets.top }}>
      <View style={{ flexDirection: 'row', alignItems: 'center', paddingHorizontal: S.md, paddingVertical: 12 }}>
        <Press onPress={() => navigation.goBack()} scaleTo={0.9}>
          <View style={{ width: 38, height: 38, borderRadius: 12, backgroundColor: surface, borderWidth: 1, borderColor: border, alignItems: 'center', justifyContent: 'center' }}>
            <Ionicons name="arrow-back" size={20} color={text} />
          </View>
        </Press>
        <Text style={{ color: text, fontSize: 18, fontWeight: '900', marginLeft: 12 }}>Study settings</Text>
      </View>

      <ScrollView contentContainerStyle={{ padding: S.md, paddingBottom: S.xl }}>
        <Card style={{ padding: S.md }}>
          <Text style={{ color: text, fontSize: 17, fontWeight: '900' }}>NCLEX exam date</Text>
          <Text style={{ color: muted, fontSize: 12.5, lineHeight: 18, marginTop: 4 }}>
            Add your scheduled date so NursePass can show a countdown on the dashboard.
          </Text>

          <TextInput
            value={value}
            onChangeText={(next) => { setValue(next); setError(''); }}
            placeholder="YYYY-MM-DD"
            placeholderTextColor={muted}
            keyboardType="numbers-and-punctuation"
            autoCapitalize="none"
            style={{ marginTop: 14, height: 48, borderWidth: 1, borderColor: error ? '#D9455A' : border, borderRadius: R.md, backgroundColor: bg, color: text, paddingHorizontal: 14, fontSize: 15 }}
          />
          {error ? <Text style={{ color: '#D9455A', fontSize: 12, marginTop: 6 }}>{error}</Text> : null}
          {preview ? <Text style={{ color: ac(2), fontSize: 12, fontWeight: '800', marginTop: 6 }}>Exam date: {preview}</Text> : null}

          <Text style={{ color: muted, fontSize: 11, fontWeight: '900', marginTop: 16, marginBottom: 8 }}>QUICK SET</Text>
          <View style={{ flexDirection: 'row', gap: 8 }}>
            {[14, 30, 60, 90].map((days) => (
              <Press key={days} onPress={() => { setValue(dayKey(days)); setError(''); }} scaleTo={0.95} style={{ flex: 1 }}>
                <View style={{ paddingVertical: 10, borderRadius: R.md, borderWidth: 1, borderColor: border, alignItems: 'center', backgroundColor: surface }}>
                  <Text style={{ color: text, fontWeight: '900', fontSize: 12 }}>+{days}d</Text>
                </View>
              </Press>
            ))}
          </View>

          <PrimaryButton label="Save exam date" icon="calendar" onPress={save} style={{ marginTop: 16 }} />
          {examDate ? <PrimaryButton label="Remove exam date" variant="outline" onPress={() => { setValue(''); setExamDate?.(null); }} style={{ marginTop: 8 }} /> : null}
        </Card>

        <Card style={{ padding: S.md, marginTop: S.md }}>
          <Text style={{ color: text, fontSize: 17, fontWeight: '900' }}>Progress on this device</Text>
          <Text style={{ color: muted, fontSize: 12.5, marginTop: 4 }}>{answered.toLocaleString()} questions answered.</Text>
          <PrimaryButton label="Reset progress" variant="outline" color="#D9455A" icon="trash" onPress={confirmReset} style={{ marginTop: 14 }} />
        </Card>

        <Card style={{ padding: S.md, marginTop: S.md }}>
          <Text style={{ color: text, fontSize: 17, fontWeight: '900' }}>About this MVP</Text>
          <Text style={{ color: muted, fontSize: 12.5, lineHeight: 19, marginTop: 6 }}>
            Progress is stored locally on this device. Ada provides educational study support, not patient-care advice. Readiness is a NursePass study metric, not an official NCLEX pass prediction.
          </Text>
        </Card>
      </ScrollView>
    </View>
  );
}
