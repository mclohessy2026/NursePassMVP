import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { Text, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useSafeAreaInsets } from 'react-native-safe-area-context';

import { Card, Press, PrimaryButton, R, S, buzz, useTokens } from '../components/ui';
import { ALL_QUESTIONS } from '../data/questions';
import { useApp } from '../store/AppContext';

const SPEED_SECONDS = 60;
const BOSS_ITEMS = 10;

function gameCopy(id) {
  if (id === 'boss') return { intro: 'Beat the pharmacology boss by scoring at least 8 out of 10.', goal: '8 / 10 to win', icon: 'medkit' };
  if (id === 'survival') return { intro: 'You have three lives. Every wrong answer costs one.', goal: 'Protect your 3 lives', icon: 'heart' };
  return { intro: 'Answer as many mixed questions correctly as you can in one minute.', goal: '60 seconds', icon: 'flash' };
}

export default function GameScreen({ route, navigation }) {
  const insets = useSafeAreaInsets();
  const { bg, surface, text, muted, border, accent, ac } = useTokens();
  const { recordGame } = useApp() || {};
  const { gameId = 'speed', title = 'Game' } = route?.params || {};
  const copy = gameCopy(gameId);

  const pool = useMemo(() => {
    const mc = ALL_QUESTIONS.filter((q) => q.type === 'mc' && Array.isArray(q.options));
    return gameId === 'boss' ? mc.filter((q) => q.category === 'pharm') : mc;
  }, [gameId]);

  const [started, setStarted] = useState(false);
  const [finished, setFinished] = useState(false);
  const [timeLeft, setTimeLeft] = useState(SPEED_SECONDS);
  const [idx, setIdx] = useState(0);
  const [score, setScore] = useState(0);
  const [answered, setAnswered] = useState(0);
  const [lives, setLives] = useState(3);
  const [selected, setSelected] = useState(null);
  const [lastCorrect, setLastCorrect] = useState(null);
  const recorded = useRef(false);

  const current = pool.length ? pool[idx % pool.length] : null;
  const won = gameId === 'boss' ? score >= 8 : gameId === 'survival' ? score >= 15 : false;

  useEffect(() => {
    if (!started || finished || gameId !== 'speed') return;
    if (timeLeft <= 0) {
      setFinished(true);
      return;
    }
    const timer = setTimeout(() => setTimeLeft((v) => v - 1), 1000);
    return () => clearTimeout(timer);
  }, [started, finished, gameId, timeLeft]);

  useEffect(() => {
    if (!finished || recorded.current) return;
    recorded.current = true;
    recordGame?.(gameId, score, won);
  }, [finished, gameId, recordGame, score, won]);

  const reset = () => {
    recorded.current = false;
    setStarted(true);
    setFinished(false);
    setTimeLeft(SPEED_SECONDS);
    setIdx(Math.floor(Math.random() * Math.max(1, pool.length)));
    setScore(0);
    setAnswered(0);
    setLives(3);
    setSelected(null);
    setLastCorrect(null);
  };

  const handleAnswer = useCallback(
    (optionIndex) => {
      if (!current || finished || selected !== null) return;
      const right = optionIndex === current.correct;
      const nextAnswered = answered + 1;
      const nextScore = score + (right ? 1 : 0);
      const nextLives = lives - (!right && gameId === 'survival' ? 1 : 0);

      setSelected(optionIndex);
      setLastCorrect(right);
      setAnswered(nextAnswered);
      if (right) setScore(nextScore);
      if (gameId === 'survival' && !right) setLives(nextLives);
      buzz(right ? 'success' : 'error');

      setTimeout(() => {
        if (gameId === 'boss' && nextAnswered >= BOSS_ITEMS) {
          setScore(nextScore);
          setFinished(true);
          return;
        }
        if (gameId === 'survival' && nextLives <= 0) {
          setScore(nextScore);
          setFinished(true);
          return;
        }
        setSelected(null);
        setLastCorrect(null);
        setIdx((i) => i + 1);
      }, 550);
    },
    [answered, current, finished, gameId, lives, score, selected]
  );

  const statusText = gameId === 'boss'
    ? `${answered}/${BOSS_ITEMS} answered`
    : gameId === 'survival'
    ? `${lives} ${lives === 1 ? 'life' : 'lives'} left`
    : `${timeLeft}s left`;

  return (
    <View style={{ flex: 1, backgroundColor: bg, paddingTop: insets.top }}>
      <View style={{ flexDirection: 'row', alignItems: 'center', paddingHorizontal: S.md, paddingVertical: 12 }}>
        <Press onPress={() => navigation.goBack()} scaleTo={0.9}>
          <View style={{ width: 38, height: 38, borderRadius: 12, backgroundColor: surface, borderWidth: 1, borderColor: border, alignItems: 'center', justifyContent: 'center' }}>
            <Ionicons name="close" size={20} color={text} />
          </View>
        </Press>
        <Text style={{ color: text, fontSize: 16, fontWeight: '900', flex: 1, textAlign: 'center' }}>{title}</Text>
        <View style={{ width: 38 }} />
      </View>

      {!started ? (
        <View style={{ flex: 1, justifyContent: 'center', padding: S.lg }}>
          <View style={{ alignItems: 'center' }}>
            <View style={{ width: 86, height: 86, borderRadius: 28, backgroundColor: `${accent}16`, alignItems: 'center', justifyContent: 'center' }}>
              <Ionicons name={copy.icon} size={42} color={accent} />
            </View>
            <Text style={{ color: text, fontSize: 24, fontWeight: '900', marginTop: S.lg, textAlign: 'center' }}>{title}</Text>
            <Text style={{ color: muted, fontSize: 14, lineHeight: 20, textAlign: 'center', marginTop: 8, maxWidth: 330 }}>{copy.intro}</Text>
            <View style={{ marginTop: S.md, paddingHorizontal: 14, paddingVertical: 8, borderRadius: 999, backgroundColor: `${ac(3)}16` }}>
              <Text style={{ color: ac(3), fontSize: 12, fontWeight: '900' }}>{copy.goal.toUpperCase()}</Text>
            </View>
          </View>
          <PrimaryButton size="lg" label="Start round" icon="play" onPress={reset} style={{ marginTop: S.xl }} />
        </View>
      ) : finished ? (
        <View style={{ flex: 1, justifyContent: 'center', padding: S.lg }}>
          <View style={{ alignItems: 'center' }}>
            <Ionicons name={won ? 'trophy' : 'flag'} size={64} color={won ? '#F2A33C' : accent} />
            <Text style={{ color: text, fontSize: 26, fontWeight: '900', marginTop: S.md }}>
              {gameId === 'boss' ? (won ? 'Boss defeated!' : 'Boss survived') : gameId === 'survival' ? 'Round over' : 'Time!'}
            </Text>
            <Text style={{ color: text, fontSize: 48, fontWeight: '900', letterSpacing: -2, marginTop: 12 }}>{score}</Text>
            <Text style={{ color: muted, fontSize: 13, fontWeight: '700' }}>CORRECT ANSWERS</Text>
            <Text style={{ color: muted, fontSize: 13, marginTop: 8 }}>
              {answered} attempted{gameId === 'speed' ? ` in ${SPEED_SECONDS} seconds` : ''}
            </Text>
          </View>
          <PrimaryButton size="lg" label="Play again" icon="reload" onPress={reset} style={{ marginTop: S.xl }} />
          <PrimaryButton size="lg" variant="outline" label="Back to Games" icon="arrow-back" onPress={() => navigation.goBack()} style={{ marginTop: 10 }} />
        </View>
      ) : current ? (
        <View style={{ flex: 1, paddingHorizontal: S.md, paddingBottom: Math.max(insets.bottom, S.md) }}>
          <View style={{ flexDirection: 'row', gap: 10, marginTop: 6 }}>
            <Card style={{ flex: 1, padding: 12 }}>
              <Text style={{ color: muted, fontSize: 10.5, fontWeight: '900' }}>STATUS</Text>
              <Text style={{ color: text, fontSize: 15, fontWeight: '900', marginTop: 3 }}>{statusText}</Text>
            </Card>
            <Card style={{ flex: 1, padding: 12 }}>
              <Text style={{ color: muted, fontSize: 10.5, fontWeight: '900' }}>SCORE</Text>
              <Text style={{ color: text, fontSize: 15, fontWeight: '900', marginTop: 3 }}>{score}</Text>
            </Card>
          </View>

          <Card style={{ padding: S.lg, marginTop: S.md }}>
            <Text style={{ color: muted, fontSize: 11, fontWeight: '900', marginBottom: 8 }}>QUESTION {answered + 1}</Text>
            <Text style={{ color: text, fontSize: 17, fontWeight: '800', lineHeight: 24 }}>{current.stem}</Text>
          </Card>

          <View style={{ marginTop: S.md, gap: 10 }}>
            {current.options.map((option, i) => {
              const picked = selected === i;
              const correctOption = selected !== null && i === current.correct;
              const wrongPick = picked && selected !== current.correct;
              const color = correctOption ? '#2E9E8F' : wrongPick ? '#D9455A' : border;
              const backgroundColor = correctOption ? '#2E9E8F14' : wrongPick ? '#D9455A14' : surface;
              return (
                <Press key={`${current.id}-${i}`} disabled={selected !== null} onPress={() => handleAnswer(i)} scaleTo={0.985}>
                  <View style={{ backgroundColor, borderColor: color, borderWidth: 1.5, borderRadius: R.md, padding: 15, flexDirection: 'row', alignItems: 'center' }}>
                    <View style={{ width: 28, height: 28, borderRadius: 10, backgroundColor: `${color}14`, alignItems: 'center', justifyContent: 'center', marginRight: 11 }}>
                      <Text style={{ color: text, fontWeight: '900', fontSize: 12 }}>{String.fromCharCode(65 + i)}</Text>
                    </View>
                    <Text style={{ color: text, flex: 1, fontSize: 14, lineHeight: 19, fontWeight: '600' }}>{option}</Text>
                    {correctOption ? <Ionicons name="checkmark-circle" size={20} color="#2E9E8F" /> : null}
                    {wrongPick ? <Ionicons name="close-circle" size={20} color="#D9455A" /> : null}
                  </View>
                </Press>
              );
            })}
          </View>

          {selected !== null ? (
            <Text style={{ color: lastCorrect ? '#2E9E8F' : '#D9455A', fontSize: 13, fontWeight: '900', textAlign: 'center', marginTop: 12 }}>
              {lastCorrect ? 'Correct' : 'Not quite'}
            </Text>
          ) : null}
        </View>
      ) : (
        <View style={{ flex: 1, alignItems: 'center', justifyContent: 'center' }}>
          <Text style={{ color: muted }}>No questions available for this game.</Text>
        </View>
      )}
    </View>
  );
}
