import React, { useEffect, useMemo, useState } from 'react';
import { ScrollView, Text, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useNavigation, useRoute } from '@react-navigation/native';
import { LinearGradient } from 'expo-linear-gradient';
import { FadeInView, LineChart } from '../ui/kit';
import TopBar from '../components/TopBar';
import { Bar, Press, PrimaryButton, R, S, Tag, accuracyColor, cardShadow, useTokens } from '../components/ui';
import { useApp } from '../store/AppContext';
import { BANK_SIZE, CATEGORIES, buildPool } from '../data/questions';

const LENGTHS = [
  { n: 10, label: 'Quick set', caption: '~8 min' },
  { n: 25, label: 'Standard', caption: '~20 min' },
  { n: 40, label: 'CAT sim', caption: '~35 min' },
];

const FORMATS = [
  { id: 'mixed', label: 'MC + NGN', icon: 'layers', caption: 'Mixed formats like the real CAT' },
  { id: 'mc', label: 'Multiple choice', icon: 'radio-button-on', caption: 'Classic single-answer items' },
  { id: 'ngn', label: 'NGN focus', icon: 'grid', caption: 'Matrix grids and select-all-that-apply' },
];

export default function PracticeScreen() {
  const insets = useSafeAreaInsets();
  const navigation = useNavigation();
  const route = useRoute();
  const { text, muted, surface, border, accent, ac, ink, bg } = useTokens();
  const app = useApp() || {};
  const { catStats = [], history = [], sessions = [], accuracy = 0 } = app;

  const [cats, setCats] = useState([]);
  const [length, setLength] = useState(25);
  const [format, setFormat] = useState('mixed');

  const preset = route.params?.preset;
  useEffect(() => {
    if (preset) setCats([preset]);
  }, [preset, route.params?.ts]);

  const poolSize = useMemo(() => {
    const opts = { cats, includeNGN: format !== 'mc', mcOnly: format === 'mc' };
    const pool = buildPool(opts);
    if (format === 'ngn') return pool.filter((q) => q.type !== 'mc').length;
    return pool.length;
  }, [cats, format]);

  const trend = useMemo(() => (history || []).slice(-10).map((h) => h?.correct || 0), [history]);
  const lastSession = (sessions || [])[0] || null;

  const toggleCat = (key) => {
    setCats((prev) => (prev.includes(key) ? prev.filter((k) => k !== key) : [...prev, key]));
  };

  const start = () => {
    navigation.navigate('Quiz', {
      cats,
      length,
      format,
      ts: Date.now(),
    });
  };

  return (
    <View style={{ flex: 1, backgroundColor: bg }}>
      <ScrollView
        contentContainerStyle={{ paddingTop: insets.top + S.sm, paddingBottom: S.xl + 80 }}
        showsVerticalScrollIndicator={false}
      >
        <TopBar
          title="Practice"
          subtitle={`${BANK_SIZE.toLocaleString()} rationaled items`}
          rightIcon="pulse"
          rightLabel="ADAPTIVE"
          rightColor={accent}
          onRight={() => navigation.navigate('Readiness')}
        />

        {/* ENGINE BANNER */}
        <FadeInView>
          <View style={{ marginHorizontal: S.md, borderRadius: R.xl, overflow: 'hidden', ...cardShadow }}>
            <LinearGradient colors={[ink, '#122539']} style={{ padding: S.md + 2 }}>
              <View style={{ flexDirection: 'row', alignItems: 'center' }}>
                <View
                  style={{
                    width: 40,
                    height: 40,
                    borderRadius: 13,
                    backgroundColor: 'rgba(255,255,255,0.12)',
                    alignItems: 'center',
                    justifyContent: 'center',
                  }}
                >
                  <Ionicons name="git-branch" size={20} color={accent} />
                </View>
                <View style={{ flex: 1, marginLeft: 12 }}>
                  <Text style={{ color: '#fff', fontSize: 16, fontWeight: '900' }}>CAT-style adaptive engine</Text>
                  <Text style={{ color: 'rgba(255,255,255,0.65)', fontSize: 12.5, marginTop: 2 }}>
                    Difficulty shifts after every answer, just like the real NCLEX
                  </Text>
                </View>
              </View>
              <View style={{ marginTop: S.md }}>
                <LineChart data={trend.length > 1 ? trend : [8, 14, 11, 19, 16, 22, 20, 26]} height={62} color={accent} />
              </View>
              <Text style={{ color: 'rgba(255,255,255,0.5)', fontSize: 11, marginTop: 6, fontWeight: '700' }}>
                CORRECT ANSWERS · LAST 10 STUDY DAYS
              </Text>
            </LinearGradient>
          </View>
        </FadeInView>

        {/* CATEGORY PICKER */}
        <View style={{ paddingHorizontal: S.md, marginTop: S.lg }}>
          <Text style={{ color: text, fontSize: 18, fontWeight: '900', letterSpacing: -0.3 }}>Choose your blueprint</Text>
          <Text style={{ color: muted, fontSize: 13, marginTop: 2, marginBottom: S.md }}>
            {cats.length === 0 ? 'All NCSBN categories included' : `${cats.length} category filter active`}
          </Text>

          {(catStats.length > 0 ? catStats : CATEGORIES).map((cat, i) => {
            const on = cats.includes(cat.key);
            const color = ac(cat.colorIndex || i);
            const acc = cat.accuracy || 0;
            return (
              <FadeInView key={cat.key} delay={i * 60}>
                <Press onPress={() => toggleCat(cat.key)} scaleTo={0.98} style={{ marginBottom: S.sm }}>
                  <View
                    style={{
                      backgroundColor: on ? `${color}12` : surface,
                      borderRadius: R.md,
                      borderWidth: 1.5,
                      borderColor: on ? color : border,
                      padding: 14,
                      flexDirection: 'row',
                      alignItems: 'center',
                      ...cardShadow,
                    }}
                  >
                    <View
                      style={{
                        width: 40,
                        height: 40,
                        borderRadius: 13,
                        backgroundColor: `${color}1F`,
                        alignItems: 'center',
                        justifyContent: 'center',
                        marginRight: 12,
                      }}
                    >
                      <Ionicons name={cat.icon || 'ellipse'} size={19} color={color} />
                    </View>
                    <View style={{ flex: 1 }}>
                      <Text style={{ color: text, fontSize: 14.5, fontWeight: '800' }}>{cat.short}</Text>
                      <Text style={{ color: muted, fontSize: 11.5, marginTop: 2, marginBottom: 6 }}>
                        {Math.round((cat.weight || 0.25) * 100)}% of the exam blueprint
                      </Text>
                      <Bar value={(acc || 0) / 100} color={accuracyColor(acc)} height={6} />
                    </View>
                    <View style={{ alignItems: 'center', marginLeft: 12, width: 44 }}>
                      <Text style={{ color: accuracyColor(acc), fontWeight: '900', fontSize: 15 }}>
                        {cat.answered ? `${acc}%` : '—'}
                      </Text>
                      <Ionicons
                        name={on ? 'checkmark-circle' : 'ellipse-outline'}
                        size={18}
                        color={on ? color : border}
                        style={{ marginTop: 4 }}
                      />
                    </View>
                  </View>
                </Press>
              </FadeInView>
            );
          })}
        </View>

        {/* LENGTH */}
        <View style={{ paddingHorizontal: S.md, marginTop: S.lg }}>
          <Text style={{ color: text, fontSize: 18, fontWeight: '900', marginBottom: S.md }}>Session length</Text>
          <View style={{ flexDirection: 'row' }}>
            {LENGTHS.map((l, i) => {
              const on = length === l.n;
              return (
                <Press key={l.n} onPress={() => setLength(l.n)} scaleTo={0.96} style={{ flex: 1, marginRight: i < 2 ? S.sm : 0 }}>
                  <View
                    style={{
                      backgroundColor: on ? ink : surface,
                      borderRadius: R.md,
                      borderWidth: 1,
                      borderColor: on ? ink : border,
                      paddingVertical: 14,
                      alignItems: 'center',
                      ...cardShadow,
                    }}
                  >
                    <Text style={{ color: on ? '#fff' : text, fontSize: 22, fontWeight: '900', letterSpacing: -1 }}>
                      {l.n}
                    </Text>
                    <Text style={{ color: on ? 'rgba(255,255,255,0.8)' : text, fontSize: 12, fontWeight: '800', marginTop: 2 }}>
                      {l.label}
                    </Text>
                    <Text style={{ color: on ? 'rgba(255,255,255,0.55)' : muted, fontSize: 10.5, marginTop: 1 }}>
                      {l.caption}
                    </Text>
                  </View>
                </Press>
              );
            })}
          </View>
        </View>

        {/* FORMAT */}
        <View style={{ paddingHorizontal: S.md, marginTop: S.lg }}>
          <Text style={{ color: text, fontSize: 18, fontWeight: '900', marginBottom: S.md }}>Item formats</Text>
          {FORMATS.map((f, i) => {
            const on = format === f.id;
            const color = ac(i + 2);
            return (
              <Press key={f.id} onPress={() => setFormat(f.id)} scaleTo={0.985} style={{ marginBottom: S.sm }}>
                <View
                  style={{
                    flexDirection: 'row',
                    alignItems: 'center',
                    backgroundColor: surface,
                    borderRadius: R.md,
                    borderWidth: 1.5,
                    borderColor: on ? color : border,
                    padding: 14,
                  }}
                >
                  <Ionicons name={f.icon} size={19} color={on ? color : muted} />
                  <View style={{ flex: 1, marginLeft: 12 }}>
                    <Text style={{ color: text, fontSize: 14.5, fontWeight: '800' }}>{f.label}</Text>
                    <Text style={{ color: muted, fontSize: 11.5, marginTop: 2 }}>{f.caption}</Text>
                  </View>
                  {on ? <Tag label="Selected" color={color} /> : null}
                </View>
              </Press>
            );
          })}
        </View>

        {/* LAST SESSION */}
        {lastSession ? (
          <FadeInView delay={80}>
            <View
              style={{
                marginHorizontal: S.md,
                marginTop: S.lg,
                backgroundColor: surface,
                borderRadius: R.lg,
                borderWidth: 1,
                borderColor: border,
                padding: S.md,
                flexDirection: 'row',
                alignItems: 'center',
                ...cardShadow,
              }}
            >
              <Ionicons name="reload" size={20} color={ac(3)} />
              <View style={{ flex: 1, marginLeft: 12 }}>
                <Text style={{ color: text, fontSize: 14, fontWeight: '800' }}>Last: {lastSession.mode}</Text>
                <Text style={{ color: muted, fontSize: 12, marginTop: 2 }}>
                  {lastSession.correct}/{lastSession.answered} correct · lifetime accuracy {accuracy}%
                </Text>
              </View>
            </View>
          </FadeInView>
        ) : null}

        <View style={{ paddingHorizontal: S.md, marginTop: S.lg }}>
          <PrimaryButton
            size="lg"
            icon="play"
            label={`Start ${Math.min(length, Math.max(1, poolSize))} questions`}
            onPress={start}
            disabled={poolSize === 0}
          />
          <Text style={{ color: muted, fontSize: 11.5, textAlign: 'center', marginTop: 10 }}>
            {poolSize === 0
              ? 'No items match those filters — widen your selection.'
              : `${poolSize} matching items available in this pool`}
          </Text>
        </View>
      </ScrollView>
    </View>
  );
}
