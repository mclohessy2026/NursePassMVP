import React from 'react';
import { ScrollView, Text, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useSafeAreaInsets } from 'react-native-safe-area-context';

import Ring from '../components/Ring';
import HeatMap from '../components/HeatMap';
import TopBar from '../components/TopBar';
import { Card, PrimaryButton, R, S, Tag, accuracyColor, useTokens } from '../components/ui';
import { daysUntil, useApp } from '../store/AppContext';

export default function ReadinessScreen({ navigation }) {
  const insets = useSafeAreaInsets();
  const { bg, text, muted, border, accent, ac } = useTokens();
  const app = useApp() || {};
  const {
    readiness = 0,
    accuracy = 0,
    answered = 0,
    catStats = [],
    weakSubs = [],
    examDate,
    plan,
    trial,
  } = app;

  const examIn = daysUntil(examDate);
  const readinessColor = accuracyColor(readiness);

  const goPractice = (categoryKey) => {
    const parent = navigation.getParent?.();
    if (parent) {
      parent.navigate('Practice', {
        screen: 'PracticeHome',
        params: categoryKey ? { preset: categoryKey, ts: Date.now() } : { ts: Date.now() },
      });
    } else {
      navigation.navigate('Practice');
    }
  };

  return (
    <View style={{ flex: 1, backgroundColor: bg }}>
      <ScrollView
        showsVerticalScrollIndicator={false}
        contentContainerStyle={{ paddingTop: insets.top + S.sm, paddingBottom: S.xl + 80 }}
      >
        <TopBar title="Readiness" subtitle="Your performance across the NCLEX blueprint" />

        <View style={{ alignItems: 'center', paddingHorizontal: S.md, marginTop: S.md }}>
          <Ring size={178} strokeWidth={15} progress={readiness / 100} color={readinessColor} trackColor={border}>
            <Text style={{ color: text, fontSize: 36, fontWeight: '900', letterSpacing: -1 }}>{readiness}</Text>
            <Text style={{ color: muted, fontSize: 12.5, fontWeight: '800' }}>READINESS</Text>
          </Ring>
          <Text style={{ color: text, fontSize: 19, fontWeight: '900', marginTop: S.md }}>
            {answered < 20 ? 'Building your baseline' : readiness >= 80 ? 'Strong trajectory' : readiness >= 70 ? 'On track in practice' : readiness >= 60 ? 'Building momentum' : 'More targeted practice needed'}
          </Text>
          <Text style={{ color: muted, fontSize: 12.5, textAlign: 'center', lineHeight: 18, marginTop: 5, maxWidth: 330 }}>
            NursePass readiness is a study estimate based on your practice accuracy and volume. It is not an official NCLEX pass prediction.
          </Text>
        </View>

        <View style={{ flexDirection: 'row', gap: 10, paddingHorizontal: S.md, marginTop: S.lg }}>
          <Card style={{ flex: 1, padding: 14, alignItems: 'center' }}>
            <Ionicons name="checkmark-done" size={20} color={ac(2)} />
            <Text style={{ color: text, fontSize: 19, fontWeight: '900', marginTop: 5 }}>{accuracy}%</Text>
            <Text style={{ color: muted, fontSize: 10.5, fontWeight: '800' }}>ACCURACY</Text>
          </Card>
          <Card style={{ flex: 1, padding: 14, alignItems: 'center' }}>
            <Ionicons name="documents" size={20} color={accent} />
            <Text style={{ color: text, fontSize: 19, fontWeight: '900', marginTop: 5 }}>{answered.toLocaleString()}</Text>
            <Text style={{ color: muted, fontSize: 10.5, fontWeight: '800' }}>ANSWERED</Text>
          </Card>
          <Card style={{ flex: 1, padding: 14, alignItems: 'center' }}>
            <Ionicons name="calendar" size={20} color={ac(3)} />
            <Text style={{ color: text, fontSize: 19, fontWeight: '900', marginTop: 5 }}>{examDate ? examIn : '—'}</Text>
            <Text style={{ color: muted, fontSize: 10.5, fontWeight: '800' }}>DAYS LEFT</Text>
          </Card>
        </View>

        <View style={{ paddingHorizontal: S.md, marginTop: S.xl }}>
          <Text style={{ color: text, fontSize: 19, fontWeight: '900' }}>Blueprint heat map</Text>
          <Text style={{ color: muted, fontSize: 13, marginTop: 3, marginBottom: S.md }}>
            Tap any area to launch focused practice in that category.
          </Text>
          <HeatMap catStats={catStats} onPickSub={(cat) => goPractice(cat.key)} />
        </View>

        <View style={{ paddingHorizontal: S.md, marginTop: S.md }}>
          <Text style={{ color: text, fontSize: 19, fontWeight: '900' }}>Priority review</Text>
          <Text style={{ color: muted, fontSize: 13, marginTop: 3, marginBottom: S.md }}>Your lowest-scoring subcategories right now.</Text>
          {(weakSubs || []).slice(0, 5).map((sub, index) => (
            <Card key={`${sub.categoryKey}-${sub.name}`} style={{ padding: 14, marginBottom: 10 }}>
              <View style={{ flexDirection: 'row', alignItems: 'center' }}>
                <View
                  style={{
                    width: 44,
                    height: 44,
                    borderRadius: 13,
                    backgroundColor: `${accuracyColor(sub.accuracy)}16`,
                    alignItems: 'center',
                    justifyContent: 'center',
                    marginRight: 12,
                  }}
                >
                  <Text style={{ color: accuracyColor(sub.accuracy), fontWeight: '900' }}>{sub.accuracy}%</Text>
                </View>
                <View style={{ flex: 1 }}>
                  <Text style={{ color: text, fontSize: 14.5, fontWeight: '800' }}>{sub.name}</Text>
                  <Text style={{ color: muted, fontSize: 11.5, marginTop: 2 }}>{sub.short} · {sub.answered} answered</Text>
                </View>
                <PrimaryButton size="sm" label="Drill" onPress={() => goPractice(sub.categoryKey)} />
              </View>
            </Card>
          ))}
        </View>

        <Card style={{ marginHorizontal: S.md, marginTop: S.lg, padding: S.md }}>
          <View style={{ flexDirection: 'row', alignItems: 'center' }}>
            <View
              style={{ width: 40, height: 40, borderRadius: 13, backgroundColor: `${accent}18`, alignItems: 'center', justifyContent: 'center', marginRight: 12 }}
            >
              <Ionicons name="sparkles" size={20} color={accent} />
            </View>
            <View style={{ flex: 1 }}>
              <Text style={{ color: text, fontWeight: '900', fontSize: 15 }}>NursePass plan</Text>
              <Text style={{ color: muted, fontSize: 12, marginTop: 2 }}>
                {trial ? `Trial active through ${trial.endsOn}` : plan ? `${plan} plan selected` : 'Unlock your full study plan when you are ready.'}
              </Text>
            </View>
            {trial || plan ? <Tag label="Active" color={ac(2)} /> : null}
          </View>
          {!trial && !plan ? (
            <PrimaryButton variant="outline" label="View plans" icon="star" onPress={() => navigation.navigate('Pricing')} style={{ marginTop: 14 }} />
          ) : null}
        </Card>
      </ScrollView>
    </View>
  );
}
