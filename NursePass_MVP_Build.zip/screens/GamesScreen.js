import React from 'react';
import { ScrollView, Text, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useSafeAreaInsets } from 'react-native-safe-area-context';

import TopBar from '../components/TopBar';
import { Card, Press, R, S, Tag, useTokens } from '../components/ui';
import { useApp } from '../store/AppContext';

const GAMES = [
  {
    id: 'boss',
    title: 'Pharm Boss Battle',
    description: '10 pharmacology questions. Land 8 correct to beat the boss.',
    icon: 'medkit',
    color: '#D9455A',
    badge: '10 ITEMS',
  },
  {
    id: 'speed',
    title: '60-Second Sprint',
    description: 'Answer as many mixed NCLEX questions as you can before time expires.',
    icon: 'flash',
    color: '#F2A33C',
    badge: 'SPEED',
  },
  {
    id: 'survival',
    title: 'Clinical Survival',
    description: 'Build the longest correct-answer run you can. Three misses ends the round.',
    icon: 'heart',
    color: '#2E9E8F',
    badge: '3 LIVES',
  },
];

export default function GamesScreen({ navigation }) {
  const insets = useSafeAreaInsets();
  const { bg, text, muted, surface, border } = useTokens();
  const { games = {} } = useApp() || {};

  return (
    <View style={{ flex: 1, backgroundColor: bg }}>
      <ScrollView
        showsVerticalScrollIndicator={false}
        contentContainerStyle={{ paddingTop: insets.top + S.sm, paddingBottom: S.xl + 80 }}
      >
        <TopBar title="Games" subtitle="Fast recall without feeling like another exam" />

        <View style={{ paddingHorizontal: S.md, marginTop: S.md }}>
          {GAMES.map((game) => {
            const stat = games?.[game.id] || { best: 0, wins: 0, plays: 0 };
            return (
              <Press
                key={game.id}
                onPress={() => navigation.navigate('Game', { gameId: game.id, title: game.title })}
                scaleTo={0.985}
                haptic="medium"
                style={{ marginBottom: S.md }}
              >
                <Card style={{ overflow: 'hidden' }}>
                  <View style={{ height: 6, backgroundColor: game.color }} />
                  <View style={{ padding: S.md }}>
                    <View style={{ flexDirection: 'row', alignItems: 'center' }}>
                      <View
                        style={{
                          width: 54,
                          height: 54,
                          borderRadius: R.md,
                          backgroundColor: `${game.color}18`,
                          alignItems: 'center',
                          justifyContent: 'center',
                          marginRight: 14,
                        }}
                      >
                        <Ionicons name={game.icon} size={27} color={game.color} />
                      </View>
                      <View style={{ flex: 1 }}>
                        <View style={{ flexDirection: 'row', alignItems: 'center', marginBottom: 4 }}>
                          <Text style={{ color: text, fontSize: 17, fontWeight: '900', flex: 1 }}>{game.title}</Text>
                          <Tag label={game.badge} color={game.color} />
                        </View>
                        <Text style={{ color: muted, fontSize: 12.5, lineHeight: 18 }}>{game.description}</Text>
                      </View>
                    </View>

                    <View style={{ flexDirection: 'row', marginTop: S.md, paddingTop: 12, borderTopWidth: 1, borderTopColor: border }}>
                      <View style={{ flex: 1 }}>
                        <Text style={{ color: text, fontSize: 16, fontWeight: '900' }}>{stat.best || 0}</Text>
                        <Text style={{ color: muted, fontSize: 10.5, fontWeight: '800' }}>BEST</Text>
                      </View>
                      <View style={{ flex: 1 }}>
                        <Text style={{ color: text, fontSize: 16, fontWeight: '900' }}>{stat.plays || 0}</Text>
                        <Text style={{ color: muted, fontSize: 10.5, fontWeight: '800' }}>PLAYS</Text>
                      </View>
                      <View style={{ flex: 1 }}>
                        <Text style={{ color: text, fontSize: 16, fontWeight: '900' }}>{stat.wins || 0}</Text>
                        <Text style={{ color: muted, fontSize: 10.5, fontWeight: '800' }}>WINS</Text>
                      </View>
                      <View style={{ width: 36, height: 36, borderRadius: 12, backgroundColor: surface, borderWidth: 1, borderColor: border, alignItems: 'center', justifyContent: 'center' }}>
                        <Ionicons name="arrow-forward" size={18} color={game.color} />
                      </View>
                    </View>
                  </View>
                </Card>
              </Press>
            );
          })}
        </View>
      </ScrollView>
    </View>
  );
}
