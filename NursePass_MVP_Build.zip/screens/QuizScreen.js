import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { Alert, ScrollView, Text, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useNavigation, useRoute } from '@react-navigation/native';
import QuestionCard from '../components/QuestionCard';
import { Bar, Press, PrimaryButton, R, S, buzz, cardShadow, useTokens } from '../components/ui';
import { buildPool, categoryByKey, gradeQuestion, nextAdaptive } from '../data/questions';
import { useApp } from '../store/AppContext';

function fmtTime(sec) {
  const s = Math.max(0, Math.floor(sec || 0));
  const m = Math.floor(s / 60);
  return `${m}:${`${s % 60}`.padStart(2, '0')}`;
}

export default function QuizScreen() {
  const insets = useSafeAreaInsets();
  const navigation = useNavigation();
  const route = useRoute();
  const { text, muted, surface, border, accent, ink, bg } = useTokens();
  const app = useApp() || {};
  const { recordAnswer, finishSession } = app;

  const cfg = route.params || {};
  const requestedTotal = Math.max(1, cfg.length || 10);
  const format = cfg.format || 'mixed';

  const pool = useMemo(() => {
    const base = buildPool({
      cats: cfg.cats || [],
      includeNGN: format !== 'mc',
      mcOnly: format === 'mc',
    });
    const filtered = format === 'ngn' ? base.filter((q) => q.type !== 'mc') : base;
    return filtered.length > 0 ? filtered : base;
  }, [cfg.cats, format]);

  const total = Math.max(1, Math.min(requestedTotal, pool.length || requestedTotal));

  const [used, setUsed] = useState([]);
  const [question, setQuestion] = useState(null);
  const [selected, setSelected] = useState(null);
  const [submitted, setSubmitted] = useState(false);
  const [isCorrect, setIsCorrect] = useState(false);
  const [ability, setAbility] = useState(2);
  const [log, setLog] = useState([]);
  const [elapsed, setElapsed] = useState(0);
  const scrollRef = useRef(null);
  const finished = useRef(false);

  const blankFor = (q) => {
    if (!q) return null;
    if (q.type === 'sata') return [];
    if (q.type === 'matrix') return (q.rows || []).map(() => undefined);
    return null;
  };

  const loadNext = useCallback(
    (usedIds, abil) => {
      const q = nextAdaptive(pool, usedIds, abil);
      if (!q) return null;
      setQuestion(q);
      setSelected(blankFor(q));
      setSubmitted(false);
      setIsCorrect(false);
      if (scrollRef.current) scrollRef.current.scrollTo({ y: 0, animated: true });
      return q;
    },
    [pool]
  );

  useEffect(() => {
    const first = nextAdaptive(pool, [], 2);
    if (first) {
      setQuestion(first);
      setSelected(blankFor(first));
    }
  }, [pool]);

  useEffect(() => {
    const id = setInterval(() => setElapsed((e) => e + 1), 1000);
    return () => clearInterval(id);
  }, []);

  const answeredCount = log.length;
  const correctCount = log.filter((l) => l.correct).length;

  const hasSelection = useMemo(() => {
    if (!question) return false;
    if (question.type === 'sata') return Array.isArray(selected) && selected.length > 0;
    if (question.type === 'matrix')
      return Array.isArray(selected) && (question.rows || []).every((_, i) => typeof selected[i] === 'number');
    return typeof selected === 'number';
  }, [question, selected]);

  const wrapUp = useCallback(
    (entries) => {
      if (finished.current) return;
      finished.current = true;
      const right = entries.filter((e) => e.correct).length;
      if (finishSession) {
        finishSession({
          mode:
            format === 'ngn'
              ? `NGN Focus · ${entries.length} items`
              : format === 'mc'
              ? `Multiple Choice · ${entries.length} items`
              : `Adaptive CAT · ${entries.length} items`,
          answered: entries.length,
          correct: right,
          category: (cfg.cats || []).length === 1 ? categoryByKey(cfg.cats[0]).short : 'Mixed',
        });
      }
      navigation.replace('QuizResult', { entries, seconds: elapsed, total: entries.length, cfg });
    },
    [cfg.cats, elapsed, finishSession, format, navigation]
  );

  const submit = () => {
    if (!question || submitted) return;
    const right = gradeQuestion(question, selected);
    setIsCorrect(right);
    setSubmitted(true);
    buzz(right ? 'success' : 'error');
    if (recordAnswer) recordAnswer(question, right);
    setAbility((a) => Math.max(1, Math.min(3, a + (right ? 0.35 : -0.42))));
    setLog((prev) => [
      ...prev,
      {
        id: question.id,
        stem: question.stem,
        rationale: question.rationale,
        sub: question.sub,
        category: question.category,
        type: question.type,
        difficulty: question.difficulty,
        correct: right,
        question,
        selected: Array.isArray(selected) ? [...selected] : selected,
      },
    ]);
  };

  const advance = () => {
    const nextUsed = [...used, question?.id].filter(Boolean);
    setUsed(nextUsed);
    const nextAbility = ability;
    if (log.length >= total || nextUsed.length >= total) {
      wrapUp(log);
      return;
    }
    const q = loadNext(nextUsed, nextAbility);
    if (!q) wrapUp(log);
  };

  const confirmQuit = () => {
    Alert.alert('End this session?', 'Your answered questions will still count toward your stats.', [
      { text: 'Keep going', style: 'cancel' },
      {
        text: 'End session',
        style: 'destructive',
        onPress: () => {
          if (log.length > 0) wrapUp(log);
          else navigation.goBack();
        },
      },
    ]);
  };

  const progress = total > 0 ? Math.min(1, answeredCount / total) : 0;
  const abilityLabel = ability >= 2.6 ? 'Above passing standard' : ability >= 1.8 ? 'At passing standard' : 'Below standard';

  return (
    <View style={{ flex: 1, backgroundColor: bg }}>
      {/* HUD */}
      <View
        style={{
          paddingTop: insets.top + S.sm,
          paddingHorizontal: S.md,
          paddingBottom: S.md,
          backgroundColor: ink,
          borderBottomLeftRadius: 24,
          borderBottomRightRadius: 24,
        }}
      >
        <View style={{ flexDirection: 'row', alignItems: 'center' }}>
          <Press onPress={confirmQuit} scaleTo={0.9}>
            <View
              style={{
                width: 34,
                height: 34,
                borderRadius: 12,
                backgroundColor: 'rgba(255,255,255,0.12)',
                alignItems: 'center',
                justifyContent: 'center',
              }}
            >
              <Ionicons name="close" size={18} color="#fff" />
            </View>
          </Press>
          <View style={{ flex: 1, marginHorizontal: 12 }}>
            <Text style={{ color: '#fff', fontWeight: '900', fontSize: 15 }}>
              Question {Math.min(answeredCount + 1, total)} of {total}
            </Text>
            <Text style={{ color: 'rgba(255,255,255,0.6)', fontSize: 11.5, marginTop: 1 }}>
              {correctCount} correct · {fmtTime(elapsed)} elapsed
            </Text>
          </View>
          <View
            style={{
              paddingHorizontal: 10,
              paddingVertical: 6,
              borderRadius: 999,
              backgroundColor: 'rgba(255,255,255,0.12)',
              flexDirection: 'row',
              alignItems: 'center',
            }}
          >
            <Ionicons name="trending-up" size={13} color={accent} />
            <Text style={{ color: '#fff', fontSize: 11.5, fontWeight: '800', marginLeft: 5 }}>
              L{Math.max(1, Math.min(3, Math.round(ability)))}
            </Text>
          </View>
        </View>

        <View style={{ marginTop: 12 }}>
          <Bar value={progress} color={accent} track="rgba(255,255,255,0.16)" height={7} />
          <Text style={{ color: 'rgba(255,255,255,0.55)', fontSize: 10.5, fontWeight: '800', marginTop: 6, letterSpacing: 0.4 }}>
            ABILITY ESTIMATE · {abilityLabel.toUpperCase()}
          </Text>
        </View>
      </View>

      <ScrollView
        ref={scrollRef}
        contentContainerStyle={{ padding: S.md, paddingBottom: 140 }}
        showsVerticalScrollIndicator={false}
      >
        {question ? (
          <QuestionCard
            question={question}
            selected={selected}
            onSelect={setSelected}
            submitted={submitted}
            correct={isCorrect}
          />
        ) : (
          <View style={{ alignItems: 'center', paddingVertical: 60 }}>
            <Ionicons name="documents-outline" size={30} color={muted} />
            <Text style={{ color: muted, marginTop: 10 }}>Loading your next item…</Text>
          </View>
        )}
      </ScrollView>

      {/* ACTION BAR */}
      <View
        style={{
          position: 'absolute',
          left: 0,
          right: 0,
          bottom: 0,
          paddingHorizontal: S.md,
          paddingTop: S.md,
          paddingBottom: Math.max(insets.bottom, S.md),
          backgroundColor: surface,
          borderTopWidth: 1,
          borderTopColor: border,
          ...cardShadow,
        }}
      >
        {submitted ? (
          <PrimaryButton
            size="lg"
            icon={log.length >= total ? 'flag' : 'arrow-forward'}
            label={log.length >= total ? 'See your results' : 'Next question'}
            onPress={advance}
          />
        ) : (
          <PrimaryButton
            size="lg"
            icon="checkmark-circle"
            label={question?.type === 'sata' ? 'Submit selections' : 'Submit answer'}
            onPress={submit}
            disabled={!hasSelection}
          />
        )}
        {!submitted && question?.type === 'sata' ? (
          <Text style={{ color: muted, fontSize: 11.5, textAlign: 'center', marginTop: 8 }}>
            Select every option that applies — partial credit is not given.
          </Text>
        ) : null}
      </View>
    </View>
  );
}
