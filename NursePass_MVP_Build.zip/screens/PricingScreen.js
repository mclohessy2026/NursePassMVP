import React, { useState } from 'react';
import { Pressable, ScrollView, Text, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useSafeAreaInsets } from 'react-native-safe-area-context';

import { Card, PrimaryButton, R, S, Tag, useTokens } from '../components/ui';
import { useApp } from '../store/AppContext';

const PLANS = [
  {
    id: 'monthly',
    title: 'Monthly',
    price: '$9.99',
    period: '/month',
    features: ['Unlimited practice sessions', 'Full readiness insights', 'Ada tutor access', 'All study games'],
  },
  {
    id: 'yearly',
    title: 'Yearly',
    price: '$59.99',
    period: '/year',
    badge: 'Best value',
    features: ['Everything in Monthly', 'About 50% lower annual cost', 'Future question-bank updates', 'Priority support'],
  },
];

export default function PricingScreen({ navigation }) {
  const insets = useSafeAreaInsets();
  const { bg, surface, text, muted, border, accent, ac } = useTokens();
  const { plan, trial, choosePlan, startTrial } = useApp() || {};
  const [selected, setSelected] = useState(plan || 'yearly');

  const activate = () => {
    choosePlan?.(selected);
    if (!trial) startTrial?.(selected, '');
    if (navigation.canGoBack()) navigation.goBack();
  };

  return (
    <View style={{ flex: 1, backgroundColor: bg, paddingTop: insets.top }}>
      <View style={{ paddingHorizontal: S.md, paddingVertical: 12 }}>
        <Pressable onPress={() => navigation.goBack()} hitSlop={12}>
          <Ionicons name="close" size={26} color={text} />
        </Pressable>
      </View>

      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={{ padding: S.md, paddingBottom: S.xl }}>
        <View style={{ alignItems: 'center', marginBottom: S.lg }}>
          <View style={{ width: 70, height: 70, borderRadius: 24, backgroundColor: `${accent}18`, alignItems: 'center', justifyContent: 'center' }}>
            <Ionicons name="star" size={34} color={accent} />
          </View>
          <Text style={{ color: text, fontSize: 26, fontWeight: '900', marginTop: 14 }}>NursePass Premium</Text>
          <Text style={{ color: muted, fontSize: 14, lineHeight: 20, textAlign: 'center', marginTop: 6, maxWidth: 340 }}>
            Build a consistent study habit with unlimited practice, readiness tracking, games, and tutor support.
          </Text>
          {trial ? <Tag label={`Trial through ${trial.endsOn}`} color={ac(2)} style={{ marginTop: 12 }} /> : <Tag label="7-day trial" color={accent} style={{ marginTop: 12 }} />}
        </View>

        <View style={{ gap: 14 }}>
          {PLANS.map((item) => {
            const active = selected === item.id;
            return (
              <Pressable key={item.id} onPress={() => setSelected(item.id)}>
                <Card style={{ padding: 18, borderWidth: 2, borderColor: active ? accent : border, backgroundColor: surface }}>
                  <View style={{ flexDirection: 'row', alignItems: 'center' }}>
                    <View style={{ flex: 1 }}>
                      <View style={{ flexDirection: 'row', alignItems: 'center' }}>
                        <Text style={{ color: text, fontSize: 18, fontWeight: '900' }}>{item.title}</Text>
                        {item.badge ? <Tag label={item.badge} color={accent} style={{ marginLeft: 8 }} /> : null}
                      </View>
                      <View style={{ flexDirection: 'row', alignItems: 'baseline', marginTop: 6 }}>
                        <Text style={{ color: text, fontSize: 29, fontWeight: '900' }}>{item.price}</Text>
                        <Text style={{ color: muted, fontSize: 13, marginLeft: 4 }}>{item.period}</Text>
                      </View>
                    </View>
                    <Ionicons name={active ? 'radio-button-on' : 'radio-button-off'} size={24} color={active ? accent : muted} />
                  </View>

                  <View style={{ marginTop: 14, gap: 8 }}>
                    {item.features.map((feature) => (
                      <View key={feature} style={{ flexDirection: 'row', alignItems: 'center' }}>
                        <Ionicons name="checkmark-circle" size={17} color={ac(2)} />
                        <Text style={{ color: text, fontSize: 13, marginLeft: 7 }}>{feature}</Text>
                      </View>
                    ))}
                  </View>
                </Card>
              </Pressable>
            );
          })}
        </View>

        <PrimaryButton
          size="lg"
          icon="sparkles"
          label={trial ? 'Use selected plan' : 'Start 7-day trial'}
          onPress={activate}
          style={{ marginTop: S.lg }}
        />
        <Text style={{ color: muted, fontSize: 11.5, lineHeight: 17, textAlign: 'center', marginTop: 10 }}>
          MVP checkout only: this build does not charge a card or App Store account. Connect Apple/Google in-app purchases before release.
        </Text>
      </ScrollView>
    </View>
  );
}
