import React from 'react';
import { Text, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { FadeInView } from '../ui/kit';
import { Press, R, S, accuracyColor, cardShadow, useTokens } from './ui';

function Cell({ sub, onPress, delay }) {
  const { surface, text, muted, border } = useTokens();
  const hasData = (sub?.answered || 0) > 0;
  const color = accuracyColor(sub?.accuracy || 0);
  const intensity = hasData ? Math.max(0.12, Math.min(0.9, (sub.accuracy || 0) / 100)) : 0.06;

  return (
    <FadeInView delay={delay} style={{ width: '50%', padding: 4 }}>
      <Press onPress={onPress} scaleTo={0.96}>
        <View
          style={{
            borderRadius: R.md,
            padding: 12,
            minHeight: 86,
            justifyContent: 'space-between',
            backgroundColor: hasData ? `${color}${intensity > 0.55 ? '26' : '1A'}` : surface,
            borderWidth: 1,
            borderColor: hasData ? `${color}55` : border,
          }}
        >
          <Text style={{ color: text, fontSize: 12.5, fontWeight: '800', lineHeight: 17 }} numberOfLines={2}>
            {sub?.name || 'Subcategory'}
          </Text>
          <View style={{ flexDirection: 'row', alignItems: 'flex-end' }}>
            <Text style={{ color, fontSize: 22, fontWeight: '900', letterSpacing: -0.6 }}>
              {hasData ? `${sub.accuracy}%` : '—'}
            </Text>
            <View style={{ flex: 1 }} />
            <Text style={{ color: muted, fontSize: 10.5, fontWeight: '700', marginBottom: 3 }}>
              {hasData ? `${sub.answered} qs` : 'no data'}
            </Text>
          </View>
        </View>
      </Press>
    </FadeInView>
  );
}

export default function HeatMap({ catStats = [], onPickSub }) {
  const { surface, text, muted, border, ac } = useTokens();

  return (
    <View>
      {(catStats || []).map((cat, ci) => (
        <View
          key={cat.key}
          style={{
            backgroundColor: surface,
            borderRadius: R.lg,
            borderWidth: 1,
            borderColor: border,
            padding: S.md - 4,
            marginBottom: S.md,
            ...cardShadow,
          }}
        >
          <View style={{ flexDirection: 'row', alignItems: 'center', paddingHorizontal: 4, marginBottom: 8 }}>
            <View
              style={{
                width: 30,
                height: 30,
                borderRadius: 10,
                backgroundColor: `${ac(cat.colorIndex || 0)}1F`,
                alignItems: 'center',
                justifyContent: 'center',
                marginRight: 10,
              }}
            >
              <Ionicons name={cat.icon || 'ellipse'} size={16} color={ac(cat.colorIndex || 0)} />
            </View>
            <View style={{ flex: 1 }}>
              <Text style={{ color: text, fontSize: 14.5, fontWeight: '900' }}>{cat.short}</Text>
              <Text style={{ color: muted, fontSize: 11.5, marginTop: 1 }}>
                {cat.answered > 0 ? `${cat.accuracy}% across ${cat.answered} questions` : 'Not yet attempted'}
              </Text>
            </View>
            <Text style={{ color: accentFor(cat), fontSize: 11, fontWeight: '900', letterSpacing: 0.4 }}>
              {label(cat.accuracy, cat.answered)}
            </Text>
          </View>
          <View style={{ flexDirection: 'row', flexWrap: 'wrap' }}>
            {(cat.subs || []).map((s, i) => (
              <Cell
                key={s.name}
                sub={s}
                delay={ci * 60 + i * 40}
                onPress={() => onPickSub && onPickSub(cat, s)}
              />
            ))}
          </View>
        </View>
      ))}
    </View>
  );
}

function label(acc, answered) {
  if (!answered) return 'NEW';
  if (acc >= 80) return 'STRONG';
  if (acc >= 70) return 'ON TRACK';
  if (acc >= 60) return 'SHAKY';
  return 'WEAK SPOT';
}

function accentFor(cat) {
  return accuracyColor(cat?.answered ? cat.accuracy : 0);
}
