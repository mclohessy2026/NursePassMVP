import React from 'react';
import { Text, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { Press, S, useTokens } from './ui';

export default function TopBar({
  title,
  subtitle,
  onBack,
  rightIcon,
  onRight,
  rightLabel,
  rightColor,
  logo,
  style,
}) {
  const { text, muted, accent, surface, border } = useTokens();

  return (
    <View
      style={[
        { flexDirection: 'row', alignItems: 'center', paddingHorizontal: S.md, paddingBottom: S.md },
        style,
      ]}
    >
      {onBack ? (
        <Press onPress={onBack} scaleTo={0.9} style={{ marginRight: 12 }}>
          <View
            style={{
              width: 38,
              height: 38,
              borderRadius: 13,
              backgroundColor: surface,
              borderWidth: 1,
              borderColor: border,
              alignItems: 'center',
              justifyContent: 'center',
            }}
          >
            <Ionicons name="chevron-back" size={20} color={text} />
          </View>
        </Press>
      ) : null}

      {logo ? (
        <View
          style={{
            width: 40,
            height: 40,
            borderRadius: 13,
            backgroundColor: accent,
            alignItems: 'center',
            justifyContent: 'center',
            marginRight: 12,
          }}
        >
          <Ionicons name="pulse" size={22} color="#fff" />
        </View>
      ) : null}

      <View style={{ flex: 1 }}>
        <Text style={{ color: text, fontSize: 20, fontWeight: '900', letterSpacing: -0.5 }}>{title}</Text>
        {subtitle ? (
          <Text style={{ color: muted, fontSize: 12, fontWeight: '600', marginTop: 1 }}>{subtitle}</Text>
        ) : null}
      </View>

      {onRight ? (
        <Press onPress={onRight} scaleTo={0.93}>
          <View
            style={{
              flexDirection: 'row',
              alignItems: 'center',
              paddingVertical: 8,
              paddingHorizontal: rightLabel ? 12 : 9,
              borderRadius: 999,
              backgroundColor: rightColor ? `${rightColor}18` : surface,
              borderWidth: 1,
              borderColor: rightColor ? `${rightColor}55` : border,
            }}
          >
            {rightIcon ? <Ionicons name={rightIcon} size={15} color={rightColor || text} /> : null}
            {rightLabel ? (
              <Text
                style={{
                  color: rightColor || text,
                  fontWeight: '900',
                  fontSize: 12,
                  marginLeft: rightIcon ? 6 : 0,
                  letterSpacing: 0.2,
                }}
              >
                {rightLabel}
              </Text>
            ) : null}
          </View>
        </Press>
      ) : null}
    </View>
  );
}
