import React, { useEffect, useRef, useState } from 'react';
import { Animated, Easing, Pressable, StyleSheet, Text, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import * as Haptics from 'expo-haptics';
import { useTheme } from '../ui/theme';

export const S = { xs: 4, sm: 8, md: 16, lg: 24, xl: 32 };
export const R = { sm: 10, md: 14, lg: 20, xl: 28 };

export const INK_FALLBACK = '#16263A';

export function useTokens() {
  const t = useTheme() || {};
  const accents = Array.isArray(t.accents) && t.accents.length > 0 ? t.accents : [t.accent || '#EA5E2A'];
  return {
    t,
    bg: t.bg || '#FAF7F2',
    surface: t.surface || '#FFFFFF',
    text: t.text || INK_FALLBACK,
    muted: t.textMuted || '#7A8494',
    accent: t.accent || '#EA5E2A',
    border: t.border || 'rgba(22,38,58,0.10)',
    accents,
    ac: (i) => accents[Math.abs(i) % accents.length] || t.accent || '#EA5E2A',
    ink: accents[1] || '#1E3A5F',
  };
}

export function buzz(kind = 'light') {
  try {
    if (kind === 'success') Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
    else if (kind === 'error') Haptics.notificationAsync(Haptics.NotificationFeedbackType.Error);
    else if (kind === 'medium') Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
    else Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
  } catch (e) {
    // haptics unavailable
  }
}

export const cardShadow = {
  shadowColor: '#000',
  shadowOffset: { width: 0, height: 2 },
  shadowOpacity: 0.08,
  shadowRadius: 8,
  elevation: 3,
};

export function Press({ children, onPress, style, scaleTo = 0.97, haptic = 'light', disabled }) {
  const scale = useRef(new Animated.Value(1)).current;
  const to = (v) =>
    Animated.spring(scale, { toValue: v, useNativeDriver: true, friction: 7, tension: 160 }).start();
  return (
    <Pressable
      disabled={disabled}
      onPressIn={() => to(scaleTo)}
      onPressOut={() => to(1)}
      onPress={() => {
        if (disabled) return;
        if (haptic) buzz(haptic);
        if (onPress) onPress();
      }}
    >
      <Animated.View style={[{ transform: [{ scale }] }, style]}>{children}</Animated.View>
    </Pressable>
  );
}

export function PrimaryButton({
  label,
  onPress,
  icon,
  color,
  variant = 'solid',
  style,
  disabled,
  size = 'md',
  haptic = 'medium',
}) {
  const { accent, surface, text, border } = useTokens();
  const c = color || accent;
  const solid = variant === 'solid';
  const outline = variant === 'outline';
  const pad = size === 'lg' ? 18 : size === 'sm' ? 10 : 14;
  const fs = size === 'lg' ? 17 : size === 'sm' ? 13 : 15;

  return (
    <Press
      onPress={onPress}
      disabled={disabled}
      haptic={haptic}
      style={[
        {
          backgroundColor: solid ? c : outline ? 'transparent' : surface,
          borderRadius: R.lg,
          paddingVertical: pad,
          paddingHorizontal: S.lg,
          flexDirection: 'row',
          alignItems: 'center',
          justifyContent: 'center',
          borderWidth: outline ? 1.5 : 0,
          borderColor: outline ? c : border,
          opacity: disabled ? 0.45 : 1,
        },
        solid ? cardShadow : null,
        style,
      ]}
    >
      {icon ? (
        <Ionicons name={icon} size={fs + 3} color={solid ? '#fff' : c} style={{ marginRight: S.sm }} />
      ) : null}
      <Text style={{ color: solid ? '#fff' : outline ? c : text, fontSize: fs, fontWeight: '800', letterSpacing: 0.2 }}>
        {label}
      </Text>
    </Press>
  );
}

/**
 * Button — thin wrapper around PrimaryButton providing a `title`/`variant`
 * API used across several screens (ResultScreen, GameScreen, ReadinessScreen,
 * PricingScreen).
 */
export function Button({ title, label, onPress, style, variant = 'solid', icon, color, disabled, size = 'md' }) {
  const mappedVariant = variant === 'secondary' ? 'outline' : variant;
  return (
    <PrimaryButton
      label={title != null ? title : label}
      onPress={onPress}
      style={style}
      variant={mappedVariant}
      icon={icon}
      color={color}
      disabled={disabled}
      size={size}
    />
  );
}

/**
 * Card — simple surfaced container used across several screens.
 */
export function Card({ children, style }) {
  const { surface, border } = useTokens();
  return (
    <View
      style={[
        {
          backgroundColor: surface,
          borderRadius: R.lg,
          borderWidth: StyleSheet.hairlineWidth,
          borderColor: border,
        },
        cardShadow,
        style,
      ]}
    >
      {children}
    </View>
  );
}

export function Pill({ label, icon, color, active, onPress, style }) {
  const { surface, muted, text, border } = useTokens();
  const c = color || '#EA5E2A';
  const body = (
    <View
      style={[
        {
          flexDirection: 'row',
          alignItems: 'center',
          paddingVertical: 8,
          paddingHorizontal: 13,
          borderRadius: 999,
          backgroundColor: active ? c : surface,
          borderWidth: 1,
          borderColor: active ? c : border,
        },
        style,
      ]}
    >
      {icon ? <Ionicons name={icon} size={14} color={active ? '#fff' : c} style={{ marginRight: 6 }} /> : null}
      <Text style={{ color: active ? '#fff' : text, fontWeight: '700', fontSize: 13 }}>{label}</Text>
    </View>
  );
  if (!onPress) return body;
  return (
    <Press onPress={onPress} scaleTo={0.94}>
      {body}
    </Press>
  );
}

export function Tag({ label, color, tone = 'soft', style }) {
  const c = color || '#EA5E2A';
  const solid = tone === 'solid';
  return (
    <View
      style={[
        {
          paddingVertical: 4,
          paddingHorizontal: 9,
          borderRadius: 8,
          backgroundColor: solid ? c : `${c}1F`,
          alignSelf: 'flex-start',
        },
        style,
      ]}
    >
      <Text style={{ color: solid ? '#fff' : c, fontSize: 11, fontWeight: '800', letterSpacing: 0.4 }}>
        {String(label || '').toUpperCase()}
      </Text>
    </View>
  );
}

export function SectionHead({ title, caption, actionLabel, onAction, color }) {
  const { text, muted, accent } = useTokens();
  return (
    <View style={{ flexDirection: 'row', alignItems: 'flex-end', marginBottom: S.md }}>
      <View style={{ flex: 1 }}>
        <Text style={{ color: text, fontSize: 18, fontWeight: '900', letterSpacing: -0.3 }}>{title}</Text>
        {caption ? <Text style={{ color: muted, fontSize: 13, marginTop: 2 }}>{caption}</Text> : null}
      </View>
      {actionLabel && onAction ? (
        <Press onPress={onAction} scaleTo={0.93}>
          <Text style={{ color: color || accent, fontWeight: '800', fontSize: 13 }}>{actionLabel}</Text>
        </Press>
      ) : null}
    </View>
  );
}

export function Bar({ value = 0, color, height = 8, track, style }) {
  const { border, accent } = useTokens();
  const v = Math.max(0, Math.min(1, Number.isFinite(value) ? value : 0));
  const w = useRef(new Animated.Value(0)).current;
  useEffect(() => {
    Animated.timing(w, { toValue: v, duration: 700, easing: Easing.out(Easing.cubic), useNativeDriver: false }).start();
  }, [v]);
  return (
    <View
      style={[
        { height, borderRadius: height / 2, backgroundColor: track || border, overflow: 'hidden', width: '100%' },
        style,
      ]}
    >
      <Animated.View
        style={{
          height,
          borderRadius: height / 2,
          backgroundColor: color || accent,
          width: w.interpolate({ inputRange: [0, 1], outputRange: ['0%', '100%'] }),
        }}
      />
    </View>
  );
}

export function Shimmer({ width = '100%', height = 16, radius = 8, style }) {
  const { border } = useTokens();
  const op = useRef(new Animated.Value(0.4)).current;
  useEffect(() => {
    const loop = Animated.loop(
      Animated.sequence([
        Animated.timing(op, { toValue: 0.9, duration: 700, useNativeDriver: true }),
        Animated.timing(op, { toValue: 0.4, duration: 700, useNativeDriver: true }),
      ])
    );
    loop.start();
    return () => loop.stop();
  }, []);
  return (
    <Animated.View
      style={[{ width, height, borderRadius: radius, backgroundColor: border, opacity: op }, style]}
    />
  );
}

export function KeyValue({ label, value, color }) {
  const { muted, text } = useTokens();
  return (
    <View style={{ alignItems: 'center' }}>
      <Text style={{ color: color || text, fontSize: 20, fontWeight: '900' }}>{value}</Text>
      <Text style={{ color: muted, fontSize: 11, fontWeight: '700', marginTop: 2, letterSpacing: 0.3 }}>
        {String(label || '').toUpperCase()}
      </Text>
    </View>
  );
}

export function accuracyColor(pctValue) {
  const v = Number.isFinite(pctValue) ? pctValue : 0;
  if (v >= 80) return '#1F9D6B';
  if (v >= 70) return '#3FA98C';
  if (v >= 60) return '#F2A33C';
  return '#D9455A';
}

export const styles = StyleSheet.create({
  fill: { flex: 1 },
  row: { flexDirection: 'row', alignItems: 'center' },
});
