import React from 'react';
import { Text, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { FadeInView } from '../ui/kit';
import { Press, R, S, Tag, cardShadow, useTokens } from './ui';
import { categoryByKey, typeLabel } from '../data/questions';

function OptionRow({ index, label, state, multi, onPress, disabled }) {
  const { surface, text, border, accent, muted } = useTokens();
  const letters = ['A', 'B', 'C', 'D', 'E', 'F'];
  const palette = {
    idle: { bg: surface, bd: border, fg: text, chip: 'rgba(22,38,58,0.06)', chipFg: muted },
    picked: { bg: `${accent}12`, bd: accent, fg: text, chip: accent, chipFg: '#fff' },
    right: { bg: 'rgba(31,157,107,0.12)', bd: '#1F9D6B', fg: text, chip: '#1F9D6B', chipFg: '#fff' },
    wrong: { bg: 'rgba(217,69,90,0.12)', bd: '#D9455A', fg: text, chip: '#D9455A', chipFg: '#fff' },
    dim: { bg: surface, bd: border, fg: muted, chip: 'rgba(22,38,58,0.05)', chipFg: muted },
  };
  const c = palette[state] || palette.idle;

  return (
    <Press onPress={onPress} disabled={disabled} scaleTo={0.985} haptic="light">
      <View
        style={{
          flexDirection: 'row',
          alignItems: 'center',
          backgroundColor: c.bg,
          borderColor: c.bd,
          borderWidth: 1.5,
          borderRadius: R.md,
          padding: 14,
          marginBottom: S.sm,
        }}
      >
        <View
          style={{
            width: 28,
            height: 28,
            borderRadius: multi ? 8 : 14,
            backgroundColor: c.chip,
            alignItems: 'center',
            justifyContent: 'center',
            marginRight: 12,
          }}
        >
          {state === 'right' ? (
            <Ionicons name="checkmark" size={17} color="#fff" />
          ) : state === 'wrong' ? (
            <Ionicons name="close" size={17} color="#fff" />
          ) : (
            <Text style={{ color: c.chipFg, fontWeight: '900', fontSize: 13 }}>{letters[index] || '?'}</Text>
          )}
        </View>
        <Text style={{ color: c.fg, flex: 1, fontSize: 15, lineHeight: 21, fontWeight: '600' }}>{label}</Text>
      </View>
    </Press>
  );
}

export default function QuestionCard({ question, selected, onSelect, submitted, correct }) {
  const { surface, text, muted, border, accent, ac } = useTokens();
  if (!question) return null;

  const cat = categoryByKey(question.category);
  const catColor = ac(cat.colorIndex || 0);
  const isSata = question.type === 'sata';
  const isMatrix = question.type === 'matrix';

  const optionState = (i) => {
    if (!submitted) {
      if (isSata) return (selected || []).includes(i) ? 'picked' : 'idle';
      return selected === i ? 'picked' : 'idle';
    }
    const isAnswer = isSata ? (question.correct || []).includes(i) : question.correct === i;
    const wasPicked = isSata ? (selected || []).includes(i) : selected === i;
    if (isAnswer) return 'right';
    if (wasPicked) return 'wrong';
    return 'dim';
  };

  const pickOption = (i) => {
    if (submitted) return;
    if (isSata) {
      const cur = Array.isArray(selected) ? [...selected] : [];
      const at = cur.indexOf(i);
      if (at >= 0) cur.splice(at, 1);
      else cur.push(i);
      onSelect(cur);
    } else {
      onSelect(i);
    }
  };

  const pickMatrix = (rowIdx, colIdx) => {
    if (submitted) return;
    const cur = Array.isArray(selected) ? [...selected] : [];
    cur[rowIdx] = colIdx;
    onSelect(cur);
  };

  return (
    <View>
      <FadeInView>
        <View
          style={{
            backgroundColor: surface,
            borderRadius: R.lg,
            padding: S.md + 2,
            borderWidth: 1,
            borderColor: border,
            marginBottom: S.md,
            ...cardShadow,
          }}
        >
          <View style={{ flexDirection: 'row', alignItems: 'center', marginBottom: 12 }}>
            <Tag label={cat.short} color={catColor} />
            <View style={{ width: 8 }} />
            <Tag label={typeLabel(question.type)} color={accent} />
            <View style={{ flex: 1 }} />
            <View style={{ flexDirection: 'row', alignItems: 'center' }}>
              {[1, 2, 3].map((d) => (
                <View
                  key={d}
                  style={{
                    width: 6,
                    height: 6,
                    borderRadius: 3,
                    marginLeft: 3,
                    backgroundColor: d <= (question.difficulty || 2) ? catColor : border,
                  }}
                />
              ))}
            </View>
          </View>

          {question.caseNote ? (
            <View
              style={{
                backgroundColor: 'rgba(22,38,58,0.04)',
                borderLeftWidth: 3,
                borderLeftColor: catColor,
                borderRadius: 10,
                padding: 12,
                marginBottom: 12,
              }}
            >
              <Text style={{ color: muted, fontSize: 11, fontWeight: '900', letterSpacing: 0.6, marginBottom: 4 }}>
                CLIENT CHART
              </Text>
              <Text style={{ color: text, fontSize: 13.5, lineHeight: 20 }}>{question.caseNote}</Text>
            </View>
          ) : null}

          <Text style={{ color: text, fontSize: 17, lineHeight: 25, fontWeight: '700' }}>{question.stem}</Text>
        </View>
      </FadeInView>

      {isMatrix ? (
        <FadeInView delay={90}>
          <View
            style={{
              backgroundColor: surface,
              borderRadius: R.lg,
              borderWidth: 1,
              borderColor: border,
              overflow: 'hidden',
              ...cardShadow,
            }}
          >
            <View style={{ flexDirection: 'row', backgroundColor: 'rgba(22,38,58,0.04)', paddingVertical: 10 }}>
              <View style={{ flex: 1.5, paddingHorizontal: 12 }}>
                <Text style={{ color: muted, fontSize: 11, fontWeight: '900', letterSpacing: 0.4 }}>FINDING</Text>
              </View>
              {(question.cols || []).map((col) => (
                <View key={col} style={{ width: 92, alignItems: 'center' }}>
                  <Text style={{ color: muted, fontSize: 11, fontWeight: '900', letterSpacing: 0.4 }}>
                    {col.toUpperCase()}
                  </Text>
                </View>
              ))}
            </View>
            {(question.rows || []).map((row, ri) => {
              const chosen = (selected || [])[ri];
              return (
                <View
                  key={row.label}
                  style={{
                    flexDirection: 'row',
                    alignItems: 'center',
                    borderTopWidth: 1,
                    borderTopColor: border,
                    paddingVertical: 12,
                  }}
                >
                  <View style={{ flex: 1.5, paddingHorizontal: 12 }}>
                    <Text style={{ color: text, fontSize: 13.5, lineHeight: 19, fontWeight: '600' }}>{row.label}</Text>
                  </View>
                  {(question.cols || []).map((col, ci) => {
                    const picked = chosen === ci;
                    let bg = 'transparent';
                    let bd = border;
                    let icon = null;
                    if (submitted) {
                      if (row.correct === ci) {
                        bg = 'rgba(31,157,107,0.16)';
                        bd = '#1F9D6B';
                        icon = 'checkmark';
                      } else if (picked) {
                        bg = 'rgba(217,69,90,0.16)';
                        bd = '#D9455A';
                        icon = 'close';
                      }
                    } else if (picked) {
                      bg = `${accent}1A`;
                      bd = accent;
                      icon = 'ellipse';
                    }
                    return (
                      <View key={col} style={{ width: 92, alignItems: 'center' }}>
                        <Press onPress={() => pickMatrix(ri, ci)} disabled={submitted} scaleTo={0.9}>
                          <View
                            style={{
                              width: 30,
                              height: 30,
                              borderRadius: 15,
                              borderWidth: 1.5,
                              borderColor: bd,
                              backgroundColor: bg,
                              alignItems: 'center',
                              justifyContent: 'center',
                            }}
                          >
                            {icon ? (
                              <Ionicons
                                name={icon}
                                size={icon === 'ellipse' ? 12 : 16}
                                color={submitted ? (row.correct === ci ? '#1F9D6B' : '#D9455A') : accent}
                              />
                            ) : null}
                          </View>
                        </Press>
                      </View>
                    );
                  })}
                </View>
              );
            })}
          </View>
        </FadeInView>
      ) : (
        <View>
          {(question.options || []).map((opt, i) => (
            <FadeInView key={`${question.id}-${i}`} delay={60 + i * 55}>
              <OptionRow
                index={i}
                label={opt}
                multi={isSata}
                state={optionState(i)}
                disabled={submitted}
                onPress={() => pickOption(i)}
              />
            </FadeInView>
          ))}
        </View>
      )}

      {submitted ? (
        <FadeInView delay={60}>
          <View
            style={{
              marginTop: S.md,
              borderRadius: R.lg,
              padding: S.md,
              backgroundColor: correct ? 'rgba(31,157,107,0.10)' : 'rgba(217,69,90,0.10)',
              borderWidth: 1,
              borderColor: correct ? 'rgba(31,157,107,0.35)' : 'rgba(217,69,90,0.35)',
            }}
          >
            <View style={{ flexDirection: 'row', alignItems: 'center', marginBottom: 8 }}>
              <Ionicons
                name={correct ? 'checkmark-circle' : 'alert-circle'}
                size={20}
                color={correct ? '#1F9D6B' : '#D9455A'}
              />
              <Text
                style={{
                  color: correct ? '#1F9D6B' : '#D9455A',
                  fontWeight: '900',
                  fontSize: 14,
                  marginLeft: 6,
                  letterSpacing: 0.3,
                }}
              >
                {correct ? 'CORRECT' : 'NOT QUITE'}
              </Text>
              <View style={{ flex: 1 }} />
              <Text style={{ color: muted, fontSize: 11, fontWeight: '800' }}>{question.sub}</Text>
            </View>
            <Text style={{ color: text, fontSize: 14.5, lineHeight: 22 }}>{question.rationale}</Text>
          </View>
        </FadeInView>
      ) : null}
    </View>
  );
}
