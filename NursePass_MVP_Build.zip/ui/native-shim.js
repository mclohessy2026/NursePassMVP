// NursePass intentionally keeps this module as a no-op compatibility hook.
// The original prototype included preview-host patches that modified React Native
// internals. Those patches are not appropriate for a production Expo app.
export {};
