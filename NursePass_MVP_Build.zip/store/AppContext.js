import React, { createContext, useCallback, useContext, useEffect, useMemo, useRef, useState } from 'react';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { CATEGORIES } from '../data/questions';

const STORE_KEY = 'nursepass.state.v2';

const CAT_WEIGHTS = { phys: 0.31, pharm: 0.29, psych: 0.13, safe: 0.27 };

export function dayKey(offset = 0) {
  const d = new Date();
  d.setDate(d.getDate() + offset);
  const m = `${d.getMonth() + 1}`.padStart(2, '0');
  const day = `${d.getDate()}`.padStart(2, '0');
  return `${d.getFullYear()}-${m}-${day}`;
}

export function prettyDate(iso) {
  if (!iso) return '';
  const parts = String(iso).split('-');
  if (parts.length < 3) return iso;
  const d = new Date(Number(parts[0]), Number(parts[1]) - 1, Number(parts[2]));
  return d.toLocaleDateString(undefined, { month: 'short', day: 'numeric' });
}

export function daysUntil(iso) {
  if (!iso) return 0;
  const parts = String(iso).split('-');
  if (parts.length < 3) return 0;
  const target = new Date(Number(parts[0]), Number(parts[1]) - 1, Number(parts[2]));
  const now = new Date();
  const ms = target.setHours(0, 0, 0, 0) - now.setHours(0, 0, 0, 0);
  return Math.max(0, Math.round(ms / 86400000));
}

function subMap(subs, entries) {
  const out = {};
  (subs || []).forEach((s, i) => {
    const e = (entries || [])[i] || { a: 0, c: 0 };
    out[s] = { answered: e.a, correct: e.c };
  });
  return out;
}

function makeSeed() {
  const cats = {};
  CATEGORIES.forEach((category) => {
    cats[category.key] = {
      answered: 0,
      correct: 0,
      subs: subMap(category.subs, category.subs.map(() => ({ a: 0, c: 0 }))),
    };
  });

  return {
    answered: 0,
    correct: 0,
    streak: 0,
    bestStreak: 0,
    lastStudyDate: null,
    examDate: null,
    history: [],
    cats,
    games: {
      boss: { best: 0, wins: 0, plays: 0 },
      speed: { best: 0, wins: 0, plays: 0 },
      survival: { best: 0, wins: 0, plays: 0 },
    },
    sessions: [],
    tasks: [
      { id: 't1', label: '10 adaptive questions', done: false },
      { id: 't2', label: 'One study game round', done: false },
      { id: 't3', label: 'Review missed rationales', done: false },
    ],
    chat: [
      {
        id: 'c1',
        role: 'tutor',
        text:
          'Hi, I am Ada — your NursePass study tutor. Ask me about a drug, lab value, disease process, prioritization, or NGN item type and I will break it down step by step.',
        ts: Date.now(),
      },
    ],
    plan: null,
    trial: null,
  };
}

const SEED = makeSeed();

export function readinessOf(state) {
  const s = state || {};
  let acc = 0;
  let wsum = 0;
  Object.keys(CAT_WEIGHTS).forEach((k) => {
    const c = (s.cats || {})[k] || {};
    const a = c.answered || 0;
    if (a > 0) {
      acc += CAT_WEIGHTS[k] * ((c.correct || 0) / a);
      wsum += CAT_WEIGHTS[k];
    }
  });
  const base = wsum > 0 ? acc / wsum : 0;
  const volume = Math.min(1, (s.answered || 0) / 300);
  const score = Math.round(base * 100 * (0.65 + 0.25 * volume) + volume * 10);
  return Math.max(0, Math.min(99, Number.isFinite(score) ? score : 0));
}

const defaultShape = {
  ...SEED,
  ready: false,
  readiness: readinessOf(SEED),
  accuracy: 0,
  catStats: [],
  weakSubs: [],
  recordAnswer: () => {},
  finishSession: () => {},
  recordGame: () => {},
  toggleTask: () => {},
  addChat: () => {},
  clearChat: () => {},
  choosePlan: () => {},
  startTrial: () => {},
  setExamDate: () => {},
  resetProgress: () => {},
};

export const AppContext = createContext(defaultShape);

export function AppProvider({ children }) {
  const [state, setState] = useState(SEED);
  const [ready, setReady] = useState(false);
  const hydrated = useRef(false);

  useEffect(() => {
    let alive = true;
    (async () => {
      try {
        const raw = await AsyncStorage.getItem(STORE_KEY);
        if (alive && raw) {
          const parsed = JSON.parse(raw);
          if (parsed && typeof parsed === 'object') {
            setState((prev) => ({ ...prev, ...parsed, cats: { ...prev.cats, ...(parsed.cats || {}) } }));
          }
        }
      } catch (e) {
        // corrupted store — keep seeded defaults
      } finally {
        if (alive) {
          hydrated.current = true;
          setReady(true);
        }
      }
    })();
    return () => {
      alive = false;
    };
  }, []);

  useEffect(() => {
    if (!hydrated.current) return;
    AsyncStorage.setItem(STORE_KEY, JSON.stringify(state)).catch(() => {});
  }, [state]);

  const recordAnswer = useCallback((question, isCorrect) => {
    if (!question) return;
    setState((prev) => {
      const key = question.category || 'phys';
      const cats = { ...(prev.cats || {}) };
      const cat = { ...(cats[key] || { answered: 0, correct: 0, subs: {} }) };
      const subs = { ...(cat.subs || {}) };
      const subName = question.sub || 'General';
      const sub = { ...(subs[subName] || { answered: 0, correct: 0 }) };
      sub.answered += 1;
      sub.correct += isCorrect ? 1 : 0;
      subs[subName] = sub;
      cat.answered = (cat.answered || 0) + 1;
      cat.correct = (cat.correct || 0) + (isCorrect ? 1 : 0);
      cat.subs = subs;
      cats[key] = cat;
      return {
        ...prev,
        cats,
        answered: (prev.answered || 0) + 1,
        correct: (prev.correct || 0) + (isCorrect ? 1 : 0),
      };
    });
  }, []);

  const finishSession = useCallback((info) => {
    const payload = info || {};
    setState((prev) => {
      const today = dayKey(0);
      const score = readinessOf(prev);
      const history = [...(prev.history || [])];
      const idx = history.findIndex((h) => h.date === today);
      if (idx >= 0) {
        history[idx] = {
          ...history[idx],
          answered: (history[idx].answered || 0) + (payload.answered || 0),
          correct: (history[idx].correct || 0) + (payload.correct || 0),
          score,
        };
      } else {
        history.push({ date: today, answered: payload.answered || 0, correct: payload.correct || 0, score });
      }
      const trimmed = history.slice(-45);

      let streak = prev.streak || 0;
      if (prev.lastStudyDate === today) {
        streak = Math.max(1, streak);
      } else if (prev.lastStudyDate === dayKey(-1)) {
        streak = streak + 1;
      } else {
        streak = 1;
      }

      const sessions = [
        {
          id: `s${Date.now()}`,
          date: today,
          mode: payload.mode || 'Practice session',
          answered: payload.answered || 0,
          correct: payload.correct || 0,
          category: payload.category || 'Mixed',
        },
        ...(prev.sessions || []),
      ].slice(0, 20);

      return {
        ...prev,
        history: trimmed,
        sessions,
        streak,
        bestStreak: Math.max(prev.bestStreak || 0, streak),
        lastStudyDate: today,
      };
    });
  }, []);

  const recordGame = useCallback((mode, score, won) => {
    setState((prev) => {
      const games = { ...(prev.games || {}) };
      const g = { ...(games[mode] || { best: 0, wins: 0, plays: 0 }) };
      g.best = Math.max(g.best || 0, Number.isFinite(score) ? score : 0);
      g.plays = (g.plays || 0) + 1;
      g.wins = (g.wins || 0) + (won ? 1 : 0);
      games[mode] = g;
      return { ...prev, games };
    });
  }, []);

  const toggleTask = useCallback((id) => {
    setState((prev) => ({
      ...prev,
      tasks: (prev.tasks || []).map((t) => (t.id === id ? { ...t, done: !t.done } : t)),
    }));
  }, []);

  const addChat = useCallback((role, text) => {
    setState((prev) => ({
      ...prev,
      chat: [...(prev.chat || []), { id: `c${Date.now()}${Math.random().toString(16).slice(2, 6)}`, role, text, ts: Date.now() }],
    }));
  }, []);

  const clearChat = useCallback(() => {
    setState((prev) => ({
      ...prev,
      chat: [
        {
          id: `c${Date.now()}`,
          role: 'tutor',
          text: 'Fresh start. What nursing concept should we work through?',
          ts: Date.now(),
        },
      ],
    }));
  }, []);

  const choosePlan = useCallback((planId) => {
    setState((prev) => ({ ...prev, plan: planId }));
  }, []);

  const startTrial = useCallback((planId, email) => {
    setState((prev) => ({
      ...prev,
      plan: planId,
      trial: { planId, email: email || '', startedAt: Date.now(), endsOn: dayKey(7) },
    }));
  }, []);

  const setExamDate = useCallback((iso) => {
    setState((prev) => ({ ...prev, examDate: iso }));
  }, []);

  const resetProgress = useCallback(() => {
    setState((prev) => ({ ...makeSeed(), plan: prev.plan || null, trial: prev.trial || null }));
  }, []);

  const derived = useMemo(() => {
    const readiness = readinessOf(state);
    const answered = state.answered || 0;
    const accuracy = answered > 0 ? Math.round(((state.correct || 0) / answered) * 100) : 0;

    const catStats = CATEGORIES.map((c) => {
      const data = (state.cats || {})[c.key] || { answered: 0, correct: 0, subs: {} };
      const a = data.answered || 0;
      const acc = a > 0 ? (data.correct || 0) / a : 0;
      return {
        ...c,
        answered: a,
        correct: data.correct || 0,
        accuracy: Math.round(acc * 100),
        ratio: acc,
        subs: (c.subs || []).map((name) => {
          const s = (data.subs || {})[name] || { answered: 0, correct: 0 };
          const sa = s.answered || 0;
          const sacc = sa > 0 ? (s.correct || 0) / sa : 0;
          return { name, answered: sa, correct: s.correct || 0, accuracy: Math.round(sacc * 100), ratio: sacc };
        }),
      };
    });

    const weakSubs = catStats
      .flatMap((c) => c.subs.map((s) => ({ ...s, category: c.name, categoryKey: c.key, short: c.short, colorIndex: c.colorIndex })))
      .filter((s) => s.answered > 0)
      .sort((a, b) => a.accuracy - b.accuracy);

    return { readiness, accuracy, catStats, weakSubs };
  }, [state]);

  const value = useMemo(
    () => ({
      ...state,
      ready,
      ...derived,
      recordAnswer,
      finishSession,
      recordGame,
      toggleTask,
      addChat,
      clearChat,
      choosePlan,
      startTrial,
      setExamDate,
      resetProgress,
    }),
    [
      state,
      ready,
      derived,
      recordAnswer,
      finishSession,
      recordGame,
      toggleTask,
      addChat,
      clearChat,
      choosePlan,
      startTrial,
      setExamDate,
      resetProgress,
    ]
  );

  return <AppContext.Provider value={value}>{children}</AppContext.Provider>;
}

export function useApp() {
  return useContext(AppContext) || defaultShape;
}
